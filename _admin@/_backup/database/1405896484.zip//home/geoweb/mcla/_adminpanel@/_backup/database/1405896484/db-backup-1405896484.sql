DROP TABLE contactus;

CREATE TABLE `contactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` text NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `map` varchar(255) NOT NULL,
  `langs` varchar(2) NOT NULL DEFAULT 'ka',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO contactus VALUES("3","11, Grishashvili str. 0105,Tbilisi,Georgia","+995 570 70 72 14 / 597 72 77 11 <br /> +995 32 272 11 81 (fax)","info@Akademkalakiedu.ge","http://akademqalaqiedu.ge/","Akademkalakiedu.ge","<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1_dhvgK493o.kJpSdF58WrpU\" width=\"560\" height=\"474\"></iframe>","en");
INSERT INTO contactus VALUES("2","11, გრიშაშვილის ქუჩა. 0105, თბილისი, საქართველო","+995 570 70 72 14 / 597 72 77 11 <br /> +995 32 272 11 81 (ფაქსი)","info@Akademkalakiedu.ge","http://akademqalaqiedu.ge/","Akademkalakiedu.ge","<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1_dhvgK493o.kJpSdF58WrpU\" width=\"560\" height=\"474\"></iframe>","ka");
INSERT INTO contactus VALUES("9","11, გრიშაშვილის ქუჩა. 0105, თბილისი, საქართველო","+995 570 70 72 14 / 597 72 77 11 <br /> +995 32 272 11 81 (ფაქსი)","info@Akademkalakiedu.ge","http://akademqalaqiedu.ge/","Akademkalakiedu.ge","<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1_dhvgK493o.kJpSdF58WrpU\" width=\"560\" height=\"474\"></iframe>","ru");



DROP TABLE departments;

CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `variable` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ka',
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO departments VALUES("1","1","ბიბლიოთეკა","librery","ka","1","0");
INSERT INTO departments VALUES("2","2","სასწავლო კლინიკა","clinic","ka","2","0");
INSERT INTO departments VALUES("3","3","სასწავლო აფთიაქი","apoteka","ka","3","0");
INSERT INTO departments VALUES("4","4","ადმინისტრაცია","","ka","4","0");
INSERT INTO departments VALUES("5","5","კაფეტერია","cafe","ka","5","0");
INSERT INTO departments VALUES("6","6","სკოლა","","ka","6","0");
INSERT INTO departments VALUES("7","7","საბავშვო ბაღი","kindergarden","ka","7","0");
INSERT INTO departments VALUES("8","8","ეკლესია","church","ka","8","0");
INSERT INTO departments VALUES("9","9","აკადემია","college","ka","9","0");
INSERT INTO departments VALUES("10","1","Librery","librery","en","1","0");
INSERT INTO departments VALUES("11","2","Training Clinic","clinic","en","2","0");
INSERT INTO departments VALUES("12","3","Study Pharmacy","apoteka","en","3","0");
INSERT INTO departments VALUES("13","4","Administration","","en","4","0");
INSERT INTO departments VALUES("14","5","Cafe","cafe","en","5","0");
INSERT INTO departments VALUES("15","6","School","","en","6","0");
INSERT INTO departments VALUES("16","7","Kindergarten","kindergarden","en","7","0");
INSERT INTO departments VALUES("17","8","Church","church","en","8","0");
INSERT INTO departments VALUES("18","9","Academy","college","en","9","0");



DROP TABLE panel_admin_rights;

CREATE TABLE `panel_admin_rights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `a_id` int(11) NOT NULL,
  `main` varchar(255) NOT NULL,
  `sub` varchar(255) NOT NULL,
  `langs` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

INSERT INTO panel_admin_rights VALUES("24","1","1,2,5,8,39,35,17,36,37,38,40,41,34","5,175,11,17,149,151,35,43,39,41,37,45,121,129,137,163,177,141,171,","ka");
INSERT INTO panel_admin_rights VALUES("30","17","1,2,5,8,39,35,17,36,37,38,40,41,34","5,175,11,17,149,151,35,43,39,41,37,45,121,129,137,163,177,141,171,","ka");
INSERT INTO panel_admin_rights VALUES("29","16","","","en");
INSERT INTO panel_admin_rights VALUES("27","1","1,2,5,8,39,35,17,36,37,38,40,41,34","6,176,12,18,150,152,36,44,40,42,38,46,122,130,138,164,142,172,","en");
INSERT INTO panel_admin_rights VALUES("28","16","1,35,17,36,37,38,40,34","35,43,39,41,37,45,121,129,137,163,177,141,","ka");
INSERT INTO panel_admin_rights VALUES("31","17","","","en");



DROP TABLE panel_admins;

CREATE TABLE `panel_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` text NOT NULL,
  `aditional_info` text NOT NULL,
  `blocked` set('1','0') NOT NULL,
  `try_time` int(11) NOT NULL,
  `permition` int(11) NOT NULL,
  `logged` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO panel_admins VALUES("1","Gio Gvazava","599623555","giorgigvazava87@gmail.com","admin","202cb962ac59075b964b07152d234b70","<p>test</p>","","1405860731","1","172","0");
INSERT INTO panel_admins VALUES("16","ლევან ჯიშკარიანი","577212151","jishkarianil@gmail.com","jishkari","15de21c670ae7c3f6f3f1f37029303c9","","","0","0","0","0");
INSERT INTO panel_admins VALUES("17","ქეთევან გვაზავა","558530144","kategvazava@gmail.com","kate","202cb962ac59075b964b07152d234b70","","","0","0","1","0");



DROP TABLE plain_text;

CREATE TABLE `plain_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `variable` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1414 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO plain_text VALUES("1","1","ka","panel","ადმინისტრირების პანელი v1.4","0");
INSERT INTO plain_text VALUES("2","1","en","panel","Admin panel v1.4","0");
INSERT INTO plain_text VALUES("3","2","ka","settings","პარამეტრები","0");
INSERT INTO plain_text VALUES("4","2","en","settings","settings","0");
INSERT INTO plain_text VALUES("5","3","ka","signout","გასვლა","0");
INSERT INTO plain_text VALUES("6","3","en","signout","signout","0");
INSERT INTO plain_text VALUES("7","4","ka","lastvisit","ბოლო ვიზიტი","0");
INSERT INTO plain_text VALUES("8","4","en","lastvisit","last visit","0");
INSERT INTO plain_text VALUES("9","5","ka","login","შემოსვლა","0");
INSERT INTO plain_text VALUES("10","5","en","login","login","0");
INSERT INTO plain_text VALUES("11","6","ka","welcome","მოგესალმებით","0");
INSERT INTO plain_text VALUES("12","6","en","welcome","welcome","0");
INSERT INTO plain_text VALUES("13","7","ka","main","მთავარი","0");
INSERT INTO plain_text VALUES("14","7","en","main","main","0");
INSERT INTO plain_text VALUES("15","8","ka","users","მომხმარებლები","0");
INSERT INTO plain_text VALUES("16","8","en","users","users","0");
INSERT INTO plain_text VALUES("17","9","ka","systemusers","სისტემის მომხმარებლები","0");
INSERT INTO plain_text VALUES("18","9","en","systemusers","system users","0");
INSERT INTO plain_text VALUES("19","10","ka","projectusers","პროექტის მომხმარებლები","0");
INSERT INTO plain_text VALUES("20","10","en","projectusers","project users","0");
INSERT INTO plain_text VALUES("21","11","ka","ipaddresses","IP მისამართები","0");
INSERT INTO plain_text VALUES("22","11","en","ipaddresses","IP addresses","0");
INSERT INTO plain_text VALUES("23","12","ka","systemipaddresses","სისტემის IP მისამართები","0");
INSERT INTO plain_text VALUES("24","12","en","systemipaddresses","system IP addresses","0");
INSERT INTO plain_text VALUES("25","13","ka","projectipaddresses","პროექტის IP მისამართები","0");
INSERT INTO plain_text VALUES("26","13","en","projectipaddresses","project IP addresses","0");
INSERT INTO plain_text VALUES("27","14","ka","logs","ლოგები","0");
INSERT INTO plain_text VALUES("28","14","en","logs","logs","0");
INSERT INTO plain_text VALUES("29","15","ka","systemlogs","სისტემის ლოგები","0");
INSERT INTO plain_text VALUES("30","15","en","systemlogs","system logs","0");
INSERT INTO plain_text VALUES("31","16","ka","projectlogs","პროექტის ლოგები","0");
INSERT INTO plain_text VALUES("32","16","en","projectlogs","project logs","0");
INSERT INTO plain_text VALUES("33","17","ka","messages","შეტყობინებები","0");
INSERT INTO plain_text VALUES("34","17","en","messages","messages","0");
INSERT INTO plain_text VALUES("35","18","ka","create","შექმნა","0");
INSERT INTO plain_text VALUES("36","18","en","create","create","0");
INSERT INTO plain_text VALUES("37","19","ka","inbox","შემოსული","0");
INSERT INTO plain_text VALUES("38","19","en","inbox","inbox","0");
INSERT INTO plain_text VALUES("39","20","ka","outbox","გასული","0");
INSERT INTO plain_text VALUES("40","20","en","outbox","outbox","0");
INSERT INTO plain_text VALUES("41","21","ka","drafts","მონახაზი","0");
INSERT INTO plain_text VALUES("42","21","en","drafts","drafts","0");
INSERT INTO plain_text VALUES("43","22","ka","deleted","წაშლილი","0");
INSERT INTO plain_text VALUES("44","22","en","deleted","deleted","0");
INSERT INTO plain_text VALUES("45","23","ka","pages","გვერდები","0");
INSERT INTO plain_text VALUES("46","23","en","pages","pages","0");
INSERT INTO plain_text VALUES("47","24","ka","carts","კალათა","0");
INSERT INTO plain_text VALUES("48","24","en","carts","carts","0");
INSERT INTO plain_text VALUES("49","25","ka","books","შეკვეთები","0");
INSERT INTO plain_text VALUES("50","25","en","books","books","0");
INSERT INTO plain_text VALUES("51","26","ka","deletedbooks","წაშლილი შეკვეთები","0");
INSERT INTO plain_text VALUES("52","26","en","deletedbooks","deleted books","0");
INSERT INTO plain_text VALUES("53","27","ka","unpayedinvoices","გადასახდელი ინვოისები","0");
INSERT INTO plain_text VALUES("54","27","en","unpayedinvoices","unpayed invoises","0");
INSERT INTO plain_text VALUES("55","28","ka","payedinvoices","გადახდილი ინვოისები","0");
INSERT INTO plain_text VALUES("56","28","en","payedinvoices","payed invoices","0");
INSERT INTO plain_text VALUES("57","29","ka","deletedinvoices","წაშლილი ინვოისები","0");
INSERT INTO plain_text VALUES("58","29","en","deletedinvoices","deleted invoices","0");
INSERT INTO plain_text VALUES("59","30","ka","filemanager","ფაილის მენეჯერი","0");
INSERT INTO plain_text VALUES("60","30","en","filemanager","filemanager","0");
INSERT INTO plain_text VALUES("61","31","ka","statistics","სტატისტიკა","0");
INSERT INTO plain_text VALUES("62","31","en","statistics","statistics","0");
INSERT INTO plain_text VALUES("63","32","ka","error","შეცდომა","0");
INSERT INTO plain_text VALUES("64","32","en","error","error","0");
INSERT INTO plain_text VALUES("65","33","ka","navigation","ნავიგაცია","0");
INSERT INTO plain_text VALUES("66","33","en","navigation","navigation","0");
INSERT INTO plain_text VALUES("67","34","ka","catalog","კატალოგი","0");
INSERT INTO plain_text VALUES("68","34","en","catalog","Catalog","0");
INSERT INTO plain_text VALUES("69","35","ka","news","სიახლეები","0");
INSERT INTO plain_text VALUES("70","35","en","news","News","0");
INSERT INTO plain_text VALUES("71","36","ka","gallery","გალერეა","0");
INSERT INTO plain_text VALUES("72","36","en","gallery","gallery","0");
INSERT INTO plain_text VALUES("73","37","ka","form","ფორმა","0");
INSERT INTO plain_text VALUES("74","37","en","form","form","0");
INSERT INTO plain_text VALUES("75","38","ka","questionanswer","კითხვა პასუხი","0");
INSERT INTO plain_text VALUES("76","38","en","questionanswer","questions answer","0");
INSERT INTO plain_text VALUES("77","39","ka","otherplugins","სხვა მოდულები","0");
INSERT INTO plain_text VALUES("78","39","en","otherplugins","other plugin","0");
INSERT INTO plain_text VALUES("79","40","ka","add","დამატება","0");
INSERT INTO plain_text VALUES("80","40","en","add","add","0");
INSERT INTO plain_text VALUES("81","41","ka","email","ელ-ფოსტა","0");
INSERT INTO plain_text VALUES("82","41","en","email","email","0");
INSERT INTO plain_text VALUES("83","42","ka","id","სკ","0");
INSERT INTO plain_text VALUES("84","42","en","id","id","0");
INSERT INTO plain_text VALUES("85","43","ka","namelname","სახელი გვარი","0");
INSERT INTO plain_text VALUES("86","43","en","namelname","name lastname","0");
INSERT INTO plain_text VALUES("87","44","ka","action","ქმედება","0");
INSERT INTO plain_text VALUES("88","44","en","action","action","0");
INSERT INTO plain_text VALUES("89","45","ka","view","ნახვა","0");
INSERT INTO plain_text VALUES("90","45","en","view","view","0");
INSERT INTO plain_text VALUES("91","46","ka","edit","რედაქტირება","0");
INSERT INTO plain_text VALUES("92","46","en","edit","edit","0");
INSERT INTO plain_text VALUES("93","47","ka","delete","წაშლა","0");
INSERT INTO plain_text VALUES("94","47","en","delete","delete","0");
INSERT INTO plain_text VALUES("95","48","ka","phone","სკ ნომერი","0");
INSERT INTO plain_text VALUES("96","48","en","phone","phone","0");
INSERT INTO plain_text VALUES("97","49","ka","type","ტიპი","0");
INSERT INTO plain_text VALUES("98","49","en","type","type","0");
INSERT INTO plain_text VALUES("99","50","ka","username","მომხმარებლის სახელი","0");
INSERT INTO plain_text VALUES("100","50","en","username","username","0");
INSERT INTO plain_text VALUES("101","51","ka","password","პაროლი","0");
INSERT INTO plain_text VALUES("102","51","en","password","password","0");
INSERT INTO plain_text VALUES("103","52","ka","fillsymbols","შეიყვანეთ სურათზე გამოსახული სიმბოლოები","0");
INSERT INTO plain_text VALUES("104","52","en","fillsymbols","please fill the symbols","0");
INSERT INTO plain_text VALUES("105","53","ka","loginsystem","სისტემაში შესვლა","0");
INSERT INTO plain_text VALUES("106","53","en","loginsystem","login system","0");
INSERT INTO plain_text VALUES("107","54","ka","fillusername","გთხოვთ შეავსოთ მომხმარებლის სახელი ველი","0");
INSERT INTO plain_text VALUES("108","54","en","fillusername","please fill in username","0");
INSERT INTO plain_text VALUES("109","55","ka","fillpassword","გთხოვთ შეავსოთ პაროლის ველი","0");
INSERT INTO plain_text VALUES("110","55","en","fillpassword","Please fill in password field","0");
INSERT INTO plain_text VALUES("111","56","ka","fillsymbolsright","გთხოვთ სწორად შეავსოთ ფოტოზე გამოსახული სიმბოლოები","0");
INSERT INTO plain_text VALUES("112","56","en","fillsymbolsright","please fill symbols correctly","0");
INSERT INTO plain_text VALUES("113","57","ka","webdeveloping","ვებ უზრუნველყოფა სტუდია 404","0");
INSERT INTO plain_text VALUES("114","57","en","webdeveloping","webdeveloping studio 404","0");
INSERT INTO plain_text VALUES("115","58","ka","allrequired","ყველა ველის შევსება სავალდებულოა","0");
INSERT INTO plain_text VALUES("116","58","en","allrequired","all fields is required","0");
INSERT INTO plain_text VALUES("117","59","ka","userorpass","მომხმარებლის სახელი ან პაროლი არასწორია","0");
INSERT INTO plain_text VALUES("118","59","en","userorpass","username or password is incorrect","0");
INSERT INTO plain_text VALUES("119","60","ka","next","წინ","0");
INSERT INTO plain_text VALUES("120","60","en","next","next","0");
INSERT INTO plain_text VALUES("121","61","ka","prev","უკან","0");
INSERT INTO plain_text VALUES("122","61","en","prev","prev","0");
INSERT INTO plain_text VALUES("123","62","ka","last","ბოლო","0");
INSERT INTO plain_text VALUES("124","62","en","last","last","0");
INSERT INTO plain_text VALUES("125","63","ka","first","პირველი","0");
INSERT INTO plain_text VALUES("126","63","en","first","first","0");
INSERT INTO plain_text VALUES("127","64","ka","search","ძიება","0");
INSERT INTO plain_text VALUES("128","64","en","search","search","0");
INSERT INTO plain_text VALUES("129","65","ka","department","განყოფილება","0");
INSERT INTO plain_text VALUES("130","65","en","department","Department","0");
INSERT INTO plain_text VALUES("131","66","ka","choose","აირჩიეთ","0");
INSERT INTO plain_text VALUES("132","66","en","choose","Choose","0");
INSERT INTO plain_text VALUES("133","67","ka","chooseDep","გთხოვთ აირჩიოთ განყოფილება","0");
INSERT INTO plain_text VALUES("134","67","en","chooseDep","Please choose department","0");
INSERT INTO plain_text VALUES("135","68","ka","enter","შესვლა","0");
INSERT INTO plain_text VALUES("136","68","en","enter","Enter","0");
INSERT INTO plain_text VALUES("137","69","ka","first_page","პირველი","0");
INSERT INTO plain_text VALUES("138","69","en","first_page","First","0");
INSERT INTO plain_text VALUES("139","70","ka","back_page","უკან","0");
INSERT INTO plain_text VALUES("140","70","en","back_page","Back","0");
INSERT INTO plain_text VALUES("141","71","ka","next_page","შემდეგი","0");
INSERT INTO plain_text VALUES("142","71","en","next_page","Next","0");
INSERT INTO plain_text VALUES("143","72","ka","last_page","ბოლო","0");
INSERT INTO plain_text VALUES("144","72","en","last_page","Last","0");
INSERT INTO plain_text VALUES("145","73","ka","fillmobile","გთხოვთ შეავსოთ საკონტაქტო ნომრის ველი","0");
INSERT INTO plain_text VALUES("146","73","en","fillmobile","Please fill in the contact number field","0");
INSERT INTO plain_text VALUES("147","74","ka","rights","უფლებები","0");
INSERT INTO plain_text VALUES("148","74","en","rights","Rights","0");
INSERT INTO plain_text VALUES("149","75","ka","fillemail","გთხოვთ შეავსოთ ელ-ფოსტის ველი","0");
INSERT INTO plain_text VALUES("150","75","en","fillemail","Please fill in the email field","0");
INSERT INTO plain_text VALUES("151","76","ka","fillnamelname","გთხოვთ შეავსოთ სახელის და გვარის ველი","0");
INSERT INTO plain_text VALUES("152","76","en","fillnamelname","Please fill in name lastname field","0");
INSERT INTO plain_text VALUES("153","77","ka","additional","დამატებითი ინფორმაცია ","0");
INSERT INTO plain_text VALUES("154","77","en","additional","Additional info","0");
INSERT INTO plain_text VALUES("155","78","ka","filladditional","გთხოვთ შეავსოთ დამატებითი ინფორმაციის ველი","0");
INSERT INTO plain_text VALUES("156","78","en","filladditional","Please fill in Additional info field","0");
INSERT INTO plain_text VALUES("157","79","ka","clear","გასუფთავება","0");
INSERT INTO plain_text VALUES("158","79","en","clear","Clear","0");
INSERT INTO plain_text VALUES("159","80","ka","requiredfields","გთხოვთ შეავსოთ *-ით აღნიშნული ველები","0");
INSERT INTO plain_text VALUES("160","80","en","requiredfields","Please fill in required fields","0");
INSERT INTO plain_text VALUES("161","81","ka","checkMinimum","გთხოვთ მონიშნოთ მინიმუმ ერთი განყოფილება","0");
INSERT INTO plain_text VALUES("162","81","en","checkMinimum","Please check minimum one department","0");
INSERT INTO plain_text VALUES("163","82","ka","erroroccurred","მოხდა შეცდომა","0");
INSERT INTO plain_text VALUES("164","82","en","erroroccurred","An error occurred","0");
INSERT INTO plain_text VALUES("165","83","ka","done","ოპერაცია წარმატებით განხორციელდა","0");
INSERT INTO plain_text VALUES("166","83","en","done","The operation was successfully carried out","0");
INSERT INTO plain_text VALUES("167","84","ka","change_password","პაროლის შეცვლა","0");
INSERT INTO plain_text VALUES("168","84","en","change_password","Change password","0");
INSERT INTO plain_text VALUES("169","85","ka","old_password","ძველი პაროლი","0");
INSERT INTO plain_text VALUES("170","85","en","old_password","Old password","0");
INSERT INTO plain_text VALUES("171","86","ka","new_password","ახალი პაროლი","0");
INSERT INTO plain_text VALUES("172","86","en","new_password","New password","0");
INSERT INTO plain_text VALUES("173","87","ka","comfirm_password","დაადასტურეთ პაროლი","0");
INSERT INTO plain_text VALUES("174","87","en","comfirm_password","Comfirm password","0");
INSERT INTO plain_text VALUES("175","88","ka","delete_elem","გნებავთ წაშალოთ ჩანაწერი","0");
INSERT INTO plain_text VALUES("176","88","en","delete_elem","Would you like to delete","0");
INSERT INTO plain_text VALUES("177","89","ka","close","დახურვა","0");
INSERT INTO plain_text VALUES("178","89","en","close","Close","0");
INSERT INTO plain_text VALUES("179","90","ka","ip_address","IP მისამართი","0");
INSERT INTO plain_text VALUES("180","90","en","ip_address","IP Address","0");
INSERT INTO plain_text VALUES("181","91","ka","fillip","გთხოვთ შეავსოთ IP მისამართის ველი","0");
INSERT INTO plain_text VALUES("182","91","en","fillip","Please fill in IP address field","0");
INSERT INTO plain_text VALUES("183","92","ka","ip","IP მისამართი","0");
INSERT INTO plain_text VALUES("184","92","en","ip","IP address","0");
INSERT INTO plain_text VALUES("185","93","ka","os","ოპერ. სისტემა","0");
INSERT INTO plain_text VALUES("186","93","en","os","OS","0");
INSERT INTO plain_text VALUES("187","94","ka","browser","ბრაუზერი","0");
INSERT INTO plain_text VALUES("188","94","en","browser","Browser","0");
INSERT INTO plain_text VALUES("189","95","ka","title","სათაური","0");
INSERT INTO plain_text VALUES("190","95","en","title","Title","0");
INSERT INTO plain_text VALUES("191","96","ka","filltitle","გთხოვთ შეავსოთ სათაურის ველი","0");
INSERT INTO plain_text VALUES("192","96","en","filltitle","Please fill in title field","0");
INSERT INTO plain_text VALUES("193","97","ka","text","ტექსტი","0");
INSERT INTO plain_text VALUES("194","97","en","text","Text","0");
INSERT INTO plain_text VALUES("195","98","ka","filltext","გთხოვთ შეავსოთ ტექსტის ველი","0");
INSERT INTO plain_text VALUES("196","98","en","filltext","Please fill in text field","0");
INSERT INTO plain_text VALUES("197","99","ka","gotourl","ბმული","0");
INSERT INTO plain_text VALUES("198","99","en","gotourl","Url","0");
INSERT INTO plain_text VALUES("199","100","ka","fillgotourl","გთხოვთ შეავსოთ ბმულის ველი","0");
INSERT INTO plain_text VALUES("200","100","en","fillgotourl","Please fill in url field","0");
INSERT INTO plain_text VALUES("201","101","ka","target","ბმულის გადასვლა","0");
INSERT INTO plain_text VALUES("202","101","en","target","url target","0");
INSERT INTO plain_text VALUES("203","102","ka","filltarget","გთხოვთ შეავსოთ ბმულის გადასვლის ველი","0");
INSERT INTO plain_text VALUES("204","102","en","filltarget","Please fill in target url field","0");
INSERT INTO plain_text VALUES("205","103","ka","photo","ფოტო","0");
INSERT INTO plain_text VALUES("206","103","en","photo","Photo","0");
INSERT INTO plain_text VALUES("207","104","ka","ka","ქართული","0");
INSERT INTO plain_text VALUES("208","104","en","ka","Georgian","0");
INSERT INTO plain_text VALUES("209","105","ka","en","ინგლისური","0");
INSERT INTO plain_text VALUES("210","105","en","en","English","0");
INSERT INTO plain_text VALUES("211","106","ka","move","გადაადგილება","0");
INSERT INTO plain_text VALUES("212","106","en","move","Move","0");
INSERT INTO plain_text VALUES("213","107","ka","date","თარიღი","0");
INSERT INTO plain_text VALUES("214","107","en","date","Date","0");
INSERT INTO plain_text VALUES("215","108","ka","meta_title","მეტა სათაური","0");
INSERT INTO plain_text VALUES("216","108","en","meta_title","Meta title","0");
INSERT INTO plain_text VALUES("217","109","ka","fillmeta_title","გთხოვთ შეავსოთ მეტა სათაური","0");
INSERT INTO plain_text VALUES("218","109","en","fillmeta_title","Please fill in meta title","0");
INSERT INTO plain_text VALUES("219","110","ka","fillmeta_desc","გთხოვთ შეავსოთ მეტა აღწერის ველი","0");
INSERT INTO plain_text VALUES("220","110","en","fillmeta_desc","Please fill in meta description field","0");
INSERT INTO plain_text VALUES("221","111","ka","meta_desc","მეტა აღწერა","0");
INSERT INTO plain_text VALUES("222","111","en","meta_desc","Meta description","0");
INSERT INTO plain_text VALUES("223","112","ka","step","საფეხური","0");
INSERT INTO plain_text VALUES("224","112","en","step","Step","0");
INSERT INTO plain_text VALUES("225","113","ka","fillstep","გთხოვთ აირციოთ საფეხურის ველი","0");
INSERT INTO plain_text VALUES("226","113","en","fillstep","Please choose step","0");
INSERT INTO plain_text VALUES("227","114","ka","youtube_video","youtube ვიდეო","0");
INSERT INTO plain_text VALUES("228","114","en","youtube_video","Youtube video link","0");
INSERT INTO plain_text VALUES("229","115","ka","fillyoutube_video","გთხოვთ შეავსოთ youtube ვიდეოს ველი","0");
INSERT INTO plain_text VALUES("230","115","en","fillyoutube_video","Please fill in youtube video link field","0");
INSERT INTO plain_text VALUES("231","116","ka","filltype","გთხოვთ აირჩიოთ ტიპი","0");
INSERT INTO plain_text VALUES("232","116","en","filltype","Please choose type","0");
INSERT INTO plain_text VALUES("233","117","ka","pagetype","გვერდის ტიპი","0");
INSERT INTO plain_text VALUES("234","117","en","pagetype","Page type","0");
INSERT INTO plain_text VALUES("235","118","ka","fillpagetype","გთხოვთ აირჩიოთ გვერდის ტიპი","0");
INSERT INTO plain_text VALUES("236","118","en","fillpagetype","Please choose page type","0");
INSERT INTO plain_text VALUES("237","119","ka","error_url","ბმულის ველში შეგიძლიათ გამოიყენოთ მხოლოდ ციფრებისა და ასოების კომბინაცია","0");
INSERT INTO plain_text VALUES("238","119","en","error_url","You can use only numbers and letters in url field","0");
INSERT INTO plain_text VALUES("239","120","ka","position","პოზ.","0");
INSERT INTO plain_text VALUES("240","120","en","position","Pos","0");
INSERT INTO plain_text VALUES("241","121","ka","fileAttach","ფაილის მიმაგრება (doc,docx,xls,xlsx,pdf,zip,rar)","0");
INSERT INTO plain_text VALUES("242","121","en","fileAttach","Attach file (doc,docx,xls,xlsx,pdf,zip,rar)","0");
INSERT INTO plain_text VALUES("243","122","ka","files","ფაილები","0");
INSERT INTO plain_text VALUES("244","122","en","files","Files","0");
INSERT INTO plain_text VALUES("245","123","ka","attach","მიმაგრება","0");
INSERT INTO plain_text VALUES("246","123","en","attach","Attach","0");
INSERT INTO plain_text VALUES("247","124","ka","showfiles","ფაილების ნახვა","0");
INSERT INTO plain_text VALUES("248","124","en","showfiles","Show files","0");
INSERT INTO plain_text VALUES("249","125","ka","addgallery","გალერიის დამატება","0");
INSERT INTO plain_text VALUES("250","125","en","addgallery","Add gallery","0");
INSERT INTO plain_text VALUES("251","126","ka","addphoto","ფოტოს დამატება","0");
INSERT INTO plain_text VALUES("252","126","en","addphoto","Add photo","0");
INSERT INTO plain_text VALUES("253","127","ka","cover","ქავერი","0");
INSERT INTO plain_text VALUES("254","127","en","cover","Cover","0");
INSERT INTO plain_text VALUES("255","128","ka","newsCategory","სიახლის კატეგორია","0");
INSERT INTO plain_text VALUES("256","128","en","newsCategory","News category","0");
INSERT INTO plain_text VALUES("257","129","ka","addnews","სიახლის დამატება","0");
INSERT INTO plain_text VALUES("258","129","en","addnews","Add news","0");
INSERT INTO plain_text VALUES("259","130","ka","short_text","მოკლე ტექსტი","0");
INSERT INTO plain_text VALUES("260","130","en","short_text","Short text","0");
INSERT INTO plain_text VALUES("261","131","ka","addcatalog","კატალოგის დამატება","0");
INSERT INTO plain_text VALUES("262","131","en","addcatalog","Add catalog","0");
INSERT INTO plain_text VALUES("263","132","ka","profesion","პროფესია","0");
INSERT INTO plain_text VALUES("264","132","en","profesion","Profesion","0");
INSERT INTO plain_text VALUES("265","133","ka","fillprofesion","გთხოვთ შეავსოთ პროფესიის ველი","0");
INSERT INTO plain_text VALUES("266","133","en","fillprofesion","Please fill in profetion field","0");
INSERT INTO plain_text VALUES("267","134","ka","dob","დაბადების თარიღი","0");
INSERT INTO plain_text VALUES("268","134","en","dob","Date of birth","0");
INSERT INTO plain_text VALUES("269","135","ka","filldob","გთხოვთ შეავსოთ დაბადების თარიღის ველი","0");
INSERT INTO plain_text VALUES("270","135","en","filldob","Please fill in date of birth field","0");
INSERT INTO plain_text VALUES("271","136","ka","bornplace","დაბადების ადგილი","0");
INSERT INTO plain_text VALUES("272","136","en","bornplace","Born place","0");
INSERT INTO plain_text VALUES("273","137","ka","fillbornplace","გთხოვთ შეავსეთ დაბადების ადგილის ველი","0");
INSERT INTO plain_text VALUES("274","137","en","fillbornplace","Please fill born place field","0");
INSERT INTO plain_text VALUES("275","138","ka","livingplace","საცხოვრებელი ადგილი","0");
INSERT INTO plain_text VALUES("276","138","en","livingplace","Living place","0");
INSERT INTO plain_text VALUES("277","139","ka","filllivingplace","გთხოვთ შეავსოთ საცხოვრებელი ადგილის ველი","0");
INSERT INTO plain_text VALUES("278","139","en","filllivingplace","Please fill in living place field","0");
INSERT INTO plain_text VALUES("279","140","ka","phonenumber","საკონტაქტო ნომერი","0");
INSERT INTO plain_text VALUES("280","140","en","phonenumber","Contact number","0");
INSERT INTO plain_text VALUES("281","141","ka","fillphonenumber","გთხოვთ შეავსოთ საკონტაქტო ნომერის ველი","0");
INSERT INTO plain_text VALUES("282","141","en","fillphonenumber","Please fill in contact number field","0");
INSERT INTO plain_text VALUES("283","142","ka","studentPortal","სტუდენტური პორტალი","0");
INSERT INTO plain_text VALUES("284","142","en","studentPortal","Student portal","0");
INSERT INTO plain_text VALUES("285","143","ka","treinings","ტრენინგები","0");
INSERT INTO plain_text VALUES("286","143","en","treinings","Treinings","0");
INSERT INTO plain_text VALUES("287","144","ka","certificate","სერთიფიკატები","0");
INSERT INTO plain_text VALUES("288","144","en","certificate","Certificates","0");
INSERT INTO plain_text VALUES("289","145","ka","languages","ენები","0");
INSERT INTO plain_text VALUES("290","145","en","languages","Languages","0");
INSERT INTO plain_text VALUES("291","146","ka","startjob","სამსახურის დაწყების თარიღი","0");
INSERT INTO plain_text VALUES("292","146","en","startjob","date of start job","0");
INSERT INTO plain_text VALUES("293","147","ka","visibility","ხილვადობა","0");
INSERT INTO plain_text VALUES("294","147","en","visibility","Visibility","0");
INSERT INTO plain_text VALUES("295","148","ka","visible","ხილვადი","0");
INSERT INTO plain_text VALUES("296","148","en","visible","Visible","0");
INSERT INTO plain_text VALUES("297","149","ka","invisible","უხილავი","0");
INSERT INTO plain_text VALUES("298","149","en","invisible","Invisible","0");
INSERT INTO plain_text VALUES("299","150","ka","shortbio","მოკლე ბიოგრაფია","0");
INSERT INTO plain_text VALUES("300","150","en","shortbio","Short biography","0");
INSERT INTO plain_text VALUES("301","151","ka","channelname","არხის სახელი","0");
INSERT INTO plain_text VALUES("302","151","en","channelname","Channel name","0");
INSERT INTO plain_text VALUES("303","152","ka","fillchannel_name","გთხოვთ შეავსოთ არხის სახელი","0");
INSERT INTO plain_text VALUES("304","152","en","fillchannel_name","Please fill in channel name","0");
INSERT INTO plain_text VALUES("305","153","ka","key","დეველოპერის გასაღები","0");
INSERT INTO plain_text VALUES("306","153","en","key","Developer key","0");
INSERT INTO plain_text VALUES("307","154","ka","fillkey","გთხოვთ შეავსოთ დეველოპერის გასაღების ველი","0");
INSERT INTO plain_text VALUES("308","154","en","fillkey","Please fill in developer key field","0");
INSERT INTO plain_text VALUES("309","155","ka","apppassword","აპლიკაციის პაროლი","0");
INSERT INTO plain_text VALUES("310","155","en","apppassword","App password","0");
INSERT INTO plain_text VALUES("311","156","ka","fillapppassword","გთხოვთ შეავსოთ აპლიკაციის პაროლი","0");
INSERT INTO plain_text VALUES("312","156","en","fillapppassword","Please fill in app password","0");
INSERT INTO plain_text VALUES("313","157","ka","channel_link","არხის ბმული","0");
INSERT INTO plain_text VALUES("314","157","en","channel_link","Channel link","0");
INSERT INTO plain_text VALUES("315","158","ka","fillchannel_link","გთხოვთ შეავსოთ არხის ბმულის ველი","0");
INSERT INTO plain_text VALUES("316","158","en","fillchannel_link","Please fill in channel link field","0");
INSERT INTO plain_text VALUES("317","159","ka","category","კატეგორია","0");
INSERT INTO plain_text VALUES("318","159","en","category","Category","0");
INSERT INTO plain_text VALUES("319","160","ka","channel","არხი","0");
INSERT INTO plain_text VALUES("320","160","en","channel","Channel","0");
INSERT INTO plain_text VALUES("321","161","ka","desc","აღწერა","0");
INSERT INTO plain_text VALUES("322","161","en","desc","Description","0");
INSERT INTO plain_text VALUES("323","162","ka","tags","ტეგები","0");
INSERT INTO plain_text VALUES("324","162","en","tags","Tags","0");
INSERT INTO plain_text VALUES("325","163","ka","filletags","გთხოვთ შეავსოთ ტეგების ველი, ტეგები გამოყავით მძიმით, შეიყვანეთ მინიმუმ 2 ტეგი","0");
INSERT INTO plain_text VALUES("326","163","en","filletags","Please fill in tag field, seperate it by comma, fill minimum 2 tags","0");
INSERT INTO plain_text VALUES("327","164","ka","video_file","ვიდეო ფაილი (ფორმატები: MOV,MPEG4,MP4,AVI,WMV,MPEGPS,FLV,3GPP,WebM)","0");
INSERT INTO plain_text VALUES("328","164","en","video_file","Video file (formats: MOV,MPEG4,MP4,AVI,WMV,MPEGPS,FLV,3GPP,WebM)","0");
INSERT INTO plain_text VALUES("329","165","ka","fillvideo_file","გთხოვთ ატვირთოთ ვიდეო","0");
INSERT INTO plain_text VALUES("330","165","en","fillvideo_file","Please upload video","0");
INSERT INTO plain_text VALUES("331","166","ka","chooseChannel","გთხოვთ აირჩიოთ არხი","0");
INSERT INTO plain_text VALUES("332","166","en","chooseChannel","Please choose channel","0");
INSERT INTO plain_text VALUES("333","167","ka","status","სტატუსი","0");
INSERT INTO plain_text VALUES("334","167","en","status","Status","0");
INSERT INTO plain_text VALUES("335","168","ka","videoplayer","ვიდეო ფლეიერი","0");
INSERT INTO plain_text VALUES("336","168","en","videoplayer","Video player","0");
INSERT INTO plain_text VALUES("337","169","ka","filmAnimation","ფილმი & ანიმაცია","0");
INSERT INTO plain_text VALUES("338","169","en","filmAnimation","Film & animation","0");
INSERT INTO plain_text VALUES("339","170","ka","auto","ავტო","0");
INSERT INTO plain_text VALUES("340","170","en","auto","Auto","0");
INSERT INTO plain_text VALUES("341","171","ka","music","მუსიკა","0");
INSERT INTO plain_text VALUES("342","171","en","music","Music","0");
INSERT INTO plain_text VALUES("343","172","ka","animal","ცხოველები","0");
INSERT INTO plain_text VALUES("344","172","en","animal","Animal","0");
INSERT INTO plain_text VALUES("345","173","ka","sport","სპორტი","0");
INSERT INTO plain_text VALUES("346","173","en","sport","Sport","0");
INSERT INTO plain_text VALUES("347","174","ka","travel","მოგზაურობა","0");
INSERT INTO plain_text VALUES("348","174","en","travel","Travel","0");
INSERT INTO plain_text VALUES("349","175","ka","games","თამაშები","0");
INSERT INTO plain_text VALUES("350","175","en","games","Games","0");
INSERT INTO plain_text VALUES("351","176","ka","comedy","კომედია","0");
INSERT INTO plain_text VALUES("352","176","en","comedy","Comedy","0");
INSERT INTO plain_text VALUES("353","177","ka","entertaiment","გართობა","0");
INSERT INTO plain_text VALUES("354","177","en","entertaiment","Entertaiment","0");
INSERT INTO plain_text VALUES("355","178","ka","education","განათლება","0");
INSERT INTO plain_text VALUES("356","178","en","education","Education","0");
INSERT INTO plain_text VALUES("357","179","ka","technic","ტექნიკა","0");
INSERT INTO plain_text VALUES("358","179","en","technic","Technic","0");
INSERT INTO plain_text VALUES("359","180","ka","movie","კინო","0");
INSERT INTO plain_text VALUES("360","180","en","movie","Movie","0");
INSERT INTO plain_text VALUES("361","181","ka","url","ბმული","0");
INSERT INTO plain_text VALUES("362","181","en","url","Url","0");
INSERT INTO plain_text VALUES("363","182","ka","banner","ბანერი (jpg,gif,png,jpeg,swf)","0");
INSERT INTO plain_text VALUES("364","182","en","banner","Banner (jpg,gif,png,jpeg,swf)","0");
INSERT INTO plain_text VALUES("365","183","ka","youtubeCode","Youtube კოდი","0");
INSERT INTO plain_text VALUES("366","183","en","youtubeCode","Youtube code","0");
INSERT INTO plain_text VALUES("367","184","ka","copy","დაკოპირება","0");
INSERT INTO plain_text VALUES("368","184","en","copy","Copy","0");
INSERT INTO plain_text VALUES("369","185","ka","select","მონიშვნა","0");
INSERT INTO plain_text VALUES("370","185","en","select","Select","0");
INSERT INTO plain_text VALUES("371","186","ka","sync","სინქრონიზაცია","0");
INSERT INTO plain_text VALUES("372","186","en","sync","Syncronaze","0");
INSERT INTO plain_text VALUES("373","187","ka","startpage","საწყისი გვერდი","0");
INSERT INTO plain_text VALUES("374","187","en","startpage","Start page","0");
INSERT INTO plain_text VALUES("375","188","ka","maxResult","მაქსიმალური რაოდენობა","0");
INSERT INTO plain_text VALUES("376","188","en","maxResult","Max result","0");
INSERT INTO plain_text VALUES("377","189","ka","from","დან","0");
INSERT INTO plain_text VALUES("378","189","en","from","From","0");
INSERT INTO plain_text VALUES("379","190","ka","to","მდე","0");
INSERT INTO plain_text VALUES("380","190","en","to","To","0");
INSERT INTO plain_text VALUES("381","191","ka","quentity","რაოდენობა","0");
INSERT INTO plain_text VALUES("382","191","en","quentity","Quentity","0");
INSERT INTO plain_text VALUES("383","192","ka","updating","განახლების პროცესშია","0");
INSERT INTO plain_text VALUES("384","192","en","updating","Updating","0");
INSERT INTO plain_text VALUES("385","193","ka","uploaded","ატვირთულია","0");
INSERT INTO plain_text VALUES("386","193","en","uploaded","Uploaded","0");
INSERT INTO plain_text VALUES("387","194","ka","inprogress","იტვირთება","0");
INSERT INTO plain_text VALUES("388","194","en","inprogress","Inprogress","0");
INSERT INTO plain_text VALUES("389","195","ka","language","ენა","0");
INSERT INTO plain_text VALUES("390","195","en","language","Language","0");
INSERT INTO plain_text VALUES("391","196","ka","vars","ცვლადი","0");
INSERT INTO plain_text VALUES("392","196","en","vars","Vars","0");
INSERT INTO plain_text VALUES("393","197","ka","changevisibility","გნებავთ შეცვალოთ ხილვადობა","0");
INSERT INTO plain_text VALUES("394","197","en","changevisibility","Would you like to change visibility","0");
INSERT INTO plain_text VALUES("395","198","ka","yes","დიახ","0");
INSERT INTO plain_text VALUES("396","198","en","yes","Yes","0");
INSERT INTO plain_text VALUES("397","199","ka","image","სურათი","0");
INSERT INTO plain_text VALUES("398","199","en","image","Image","0");
INSERT INTO plain_text VALUES("399","200","ka","mainTitle","საქართველოს ბიზნესისა და მედიცინის აკადემია","0");
INSERT INTO plain_text VALUES("400","200","en","mainTitle","Academy of Business and Medicine","0");
INSERT INTO plain_text VALUES("401","201","ka","send","გაგზავნა","0");
INSERT INTO plain_text VALUES("402","201","en","send","Send","0");
INSERT INTO plain_text VALUES("403","202","ka","name","სახელი","0");
INSERT INTO plain_text VALUES("404","202","en","name","Name","0");
INSERT INTO plain_text VALUES("405","203","ka","message","შეტყობინება","0");
INSERT INTO plain_text VALUES("406","203","en","message","Message","0");
INSERT INTO plain_text VALUES("407","204","ka","textus","მოგვწერეთ","0");
INSERT INTO plain_text VALUES("408","204","en","textus","Send us message","0");
INSERT INTO plain_text VALUES("409","205","ka","contact","კონტაქტი","0");
INSERT INTO plain_text VALUES("410","205","en","contact","Contact","0");
INSERT INTO plain_text VALUES("411","206","ka","librery_text","ბიბლიოთეკა ტექსტი","0");
INSERT INTO plain_text VALUES("412","206","en","librery_text","Librery text","0");
INSERT INTO plain_text VALUES("413","207","ka","librery","ბიბლიოთეკა","0");
INSERT INTO plain_text VALUES("414","207","en","librery","Librery","0");
INSERT INTO plain_text VALUES("415","208","ka","apoteka","აფტიაქი","0");
INSERT INTO plain_text VALUES("416","208","en","apoteka","Apoteka","0");
INSERT INTO plain_text VALUES("417","209","ka","apoteka_text","აფტიაქი ტექსტი","0");
INSERT INTO plain_text VALUES("418","209","en","apoteka_text","Apoteka text","0");
INSERT INTO plain_text VALUES("419","210","ka","clinic_text","კლინიკა ტექსტი","0");
INSERT INTO plain_text VALUES("420","210","en","clinic_text","Clinic text","0");
INSERT INTO plain_text VALUES("421","211","ka","clinic","კლინიკა","0");
INSERT INTO plain_text VALUES("422","211","en","clinic","Clinic","0");
INSERT INTO plain_text VALUES("423","212","ka","academy_text","აკადემია აკადემია აკადემი ტექსტი","0");
INSERT INTO plain_text VALUES("424","212","en","academy_text","Academy text","0");
INSERT INTO plain_text VALUES("425","213","ka","academy","აკადემია","0");
INSERT INTO plain_text VALUES("426","213","en","academy","Academy","0");
INSERT INTO plain_text VALUES("427","214","ka","show_all_images","ყველა ფოტო","0");
INSERT INTO plain_text VALUES("428","214","en","show_all_images","All photos","0");
INSERT INTO plain_text VALUES("429","215","ka","error_description","ზოგჯერ თქვენ ცდილობთ ეწვიოთ ვებ-გვერდს რომელიც არ არსებობს, ან გადაიტანეს, ან ბმული შეცვალეს; ან ბმული შეცდომით დაბეჭდეთ; ან თქვენ დაკლიკეთ შეცდომით დაბეჭდილ ბმულზე; ამ და სხვა შეცდომების გამო ვხედავთ ამ გვერდს.","0");
INSERT INTO plain_text VALUES("430","215","en","error_description","Sometimes you try to visit a webpage but it doesn\'t exist, or it has been removed, or its URL has been changed; or you mistype its URL; or you click a link that has a mistyped URL; in those (and other) cases you get the 404 / Not Found error message.","0");
INSERT INTO plain_text VALUES("431","216","ka","error_msg","შეცდომა 404 გვერდი ვერ მოიძებნა","0");
INSERT INTO plain_text VALUES("432","216","en","error_msg","ERROR 404 PAGE NOT FOUND","0");
INSERT INTO plain_text VALUES("433","217","ka","variable","ცვლადი","0");
INSERT INTO plain_text VALUES("434","217","en","variable","Variable","0");
INSERT INTO plain_text VALUES("435","218","ka","fillvariable","გთხოვთ შეავსოთ ცვლადის ველი","0");
INSERT INTO plain_text VALUES("436","218","en","fillvariable","Please fill in variable field","0");
INSERT INTO plain_text VALUES("1159","236","en","actioned_idx","Actioned id","0");
INSERT INTO plain_text VALUES("1157","235","en","view_action","Admin action","0");
INSERT INTO plain_text VALUES("1158","236","ka","actioned_idx","საინდენტიფიკაციო ობიექტი","0");
INSERT INTO plain_text VALUES("1155","234","en","admin","admin","0");
INSERT INTO plain_text VALUES("1156","235","ka","view_action","ადმინისტრატორის მოქმედება","0");
INSERT INTO plain_text VALUES("1152","233","ka","backuped","დარეზერვებულია","0");
INSERT INTO plain_text VALUES("1153","233","en","backuped","Backuped","0");
INSERT INTO plain_text VALUES("1154","234","ka","admin","ადმინი","0");
INSERT INTO plain_text VALUES("1142","228","ka","makeBackup","დარეზერვება","0");
INSERT INTO plain_text VALUES("1143","228","en","makeBackup","Make backup","0");
INSERT INTO plain_text VALUES("1144","229","ka","full","სრული","0");
INSERT INTO plain_text VALUES("1145","229","en","full","Full","0");
INSERT INTO plain_text VALUES("1146","230","ka","files","ფაილები","0");
INSERT INTO plain_text VALUES("1147","230","en","files","Files","0");
INSERT INTO plain_text VALUES("1148","231","ka","database","მონაცემთა ბაზა","0");
INSERT INTO plain_text VALUES("1149","231","en","database","Database","0");
INSERT INTO plain_text VALUES("1150","232","ka","proccess","მიმდინარეობს","0");
INSERT INTO plain_text VALUES("1151","232","en","proccess","Proccessing","0");
INSERT INTO plain_text VALUES("1140","227","ka","chooseLanguage","აირჩიეთ ენა","0");
INSERT INTO plain_text VALUES("1141","227","en","chooseLanguage","Choose language","0");
INSERT INTO plain_text VALUES("1139","226","en","unsubscribe","unsubscribe","0");
INSERT INTO plain_text VALUES("1138","226","ka","unsubscribe","გაუქმება","0");
INSERT INTO plain_text VALUES("1137","225","en","subscribe","subscribe","0");
INSERT INTO plain_text VALUES("1128","221","ka","question","კითხვა","0");
INSERT INTO plain_text VALUES("1129","221","en","question","Question","0");
INSERT INTO plain_text VALUES("1130","222","ka","allpolls","ყველა გამოკითხვა","0");
INSERT INTO plain_text VALUES("1131","222","en","allpolls","All polls","0");
INSERT INTO plain_text VALUES("1132","223","ka","poll","გამოკითხვა","0");
INSERT INTO plain_text VALUES("1133","223","en","poll","Poll","0");
INSERT INTO plain_text VALUES("1134","224","ka","newsletter","სიახლეების გამოწერა","0");
INSERT INTO plain_text VALUES("1135","224","en","newsletter","Newsletter","0");
INSERT INTO plain_text VALUES("1136","225","ka","subscribe","გამოწერა","0");
INSERT INTO plain_text VALUES("1127","220","en","moreanswers","Add more answers","0");
INSERT INTO plain_text VALUES("1126","220","ka","moreanswers","პასუხის დამატება","0");
INSERT INTO plain_text VALUES("1124","219","ka","answers","პასუხი","0");
INSERT INTO plain_text VALUES("1125","219","en","answers","Answer","0");
INSERT INTO plain_text VALUES("1160","237","ka","data","მონაცემები","0");
INSERT INTO plain_text VALUES("1161","237","en","data","მონაცემები","0");
INSERT INTO plain_text VALUES("1162","238","ka","chart","დიაგრამა","0");
INSERT INTO plain_text VALUES("1163","238","en","chart","Chart","0");
INSERT INTO plain_text VALUES("1164","239","ka","created","შექმნილია","0");
INSERT INTO plain_text VALUES("1165","239","en","created","Created","0");
INSERT INTO plain_text VALUES("1166","240","ka","get_chart","დიაგრამის ჩასმის კოდი","0");
INSERT INTO plain_text VALUES("1167","240","en","get_chart","Chart insert code","0");
INSERT INTO plain_text VALUES("1168","241","ka","UserBlocked","მომხმარებლის სახელი დაიბლოკა გთხოვთ სცადოთ მოგვიანებით","0");
INSERT INTO plain_text VALUES("1169","241","en","UserBlocked","username has been blocked please try again later","0");
INSERT INTO plain_text VALUES("1170","242","ka","noRight","თქვენ არ გაქვთ არსებული კონტენტის განახლების უფლება","0");
INSERT INTO plain_text VALUES("1171","242","en","noRight","You have no right to update the content","0");
INSERT INTO plain_text VALUES("1172","1","ru","panel","ადმინისტრირების პანელი v1.4","0");
INSERT INTO plain_text VALUES("1173","2","ru","settings","პარამეტრები","0");
INSERT INTO plain_text VALUES("1174","3","ru","signout","გასვლა","0");
INSERT INTO plain_text VALUES("1175","4","ru","lastvisit","ბოლო ვიზიტი","0");
INSERT INTO plain_text VALUES("1176","5","ru","login","შემოსვლა","0");
INSERT INTO plain_text VALUES("1177","6","ru","welcome","მოგესალმებით","0");
INSERT INTO plain_text VALUES("1178","7","ru","main","მთავარი","0");
INSERT INTO plain_text VALUES("1179","8","ru","users","მომხმარებლები","0");
INSERT INTO plain_text VALUES("1180","9","ru","systemusers","სისტემის მომხმარებლები","0");
INSERT INTO plain_text VALUES("1181","10","ru","projectusers","პროექტის მომხმარებლები","0");
INSERT INTO plain_text VALUES("1182","11","ru","ipaddresses","IP მისამართები","0");
INSERT INTO plain_text VALUES("1183","12","ru","systemipaddresses","სისტემის IP მისამართები","0");
INSERT INTO plain_text VALUES("1184","13","ru","projectipaddresses","პროექტის IP მისამართები","0");
INSERT INTO plain_text VALUES("1185","14","ru","logs","ლოგები","0");
INSERT INTO plain_text VALUES("1186","15","ru","systemlogs","სისტემის ლოგები","0");
INSERT INTO plain_text VALUES("1187","16","ru","projectlogs","პროექტის ლოგები","0");
INSERT INTO plain_text VALUES("1188","17","ru","messages","შეტყობინებები","0");
INSERT INTO plain_text VALUES("1189","18","ru","create","შექმნა","0");
INSERT INTO plain_text VALUES("1190","19","ru","inbox","შემოსული","0");
INSERT INTO plain_text VALUES("1191","20","ru","outbox","გასული","0");
INSERT INTO plain_text VALUES("1192","21","ru","drafts","მონახაზი","0");
INSERT INTO plain_text VALUES("1193","22","ru","deleted","წაშლილი","0");
INSERT INTO plain_text VALUES("1194","23","ru","pages","გვერდები","0");
INSERT INTO plain_text VALUES("1195","24","ru","carts","კალათა","0");
INSERT INTO plain_text VALUES("1196","25","ru","books","შეკვეთები","0");
INSERT INTO plain_text VALUES("1197","26","ru","deletedbooks","წაშლილი შეკვეთები","0");
INSERT INTO plain_text VALUES("1198","27","ru","unpayedinvoices","გადასახდელი ინვოისები","0");
INSERT INTO plain_text VALUES("1199","28","ru","payedinvoices","გადახდილი ინვოისები","0");
INSERT INTO plain_text VALUES("1200","29","ru","deletedinvoices","წაშლილი ინვოისები","0");
INSERT INTO plain_text VALUES("1201","30","ru","filemanager","ფაილის მენეჯერი","0");
INSERT INTO plain_text VALUES("1202","31","ru","statistics","სტატისტიკა","0");
INSERT INTO plain_text VALUES("1203","32","ru","error","შეცდომა","0");
INSERT INTO plain_text VALUES("1204","33","ru","navigation","ნავიგაცია","0");
INSERT INTO plain_text VALUES("1205","34","ru","catalog","კატალოგი","0");
INSERT INTO plain_text VALUES("1206","35","ru","news","სიახლეები","0");
INSERT INTO plain_text VALUES("1207","36","ru","gallery","გალერეა","0");
INSERT INTO plain_text VALUES("1208","37","ru","form","ფორმა","0");
INSERT INTO plain_text VALUES("1209","38","ru","questionanswer","კითხვა პასუხი","0");
INSERT INTO plain_text VALUES("1210","39","ru","otherplugins","სხვა მოდულები","0");
INSERT INTO plain_text VALUES("1211","40","ru","add","დამატება","0");
INSERT INTO plain_text VALUES("1212","41","ru","email","ელ-ფოსტა","0");
INSERT INTO plain_text VALUES("1213","42","ru","id","სკ","0");
INSERT INTO plain_text VALUES("1214","43","ru","namelname","სახელი გვარი","0");
INSERT INTO plain_text VALUES("1215","44","ru","action","ქმედება","0");
INSERT INTO plain_text VALUES("1216","45","ru","view","ნახვა","0");
INSERT INTO plain_text VALUES("1217","46","ru","edit","რედაქტირება","0");
INSERT INTO plain_text VALUES("1218","47","ru","delete","წაშლა","0");
INSERT INTO plain_text VALUES("1219","48","ru","phone","სკ ნომერი","0");
INSERT INTO plain_text VALUES("1220","49","ru","type","ტიპი","0");
INSERT INTO plain_text VALUES("1221","50","ru","username","მომხმარებლის სახელი","0");
INSERT INTO plain_text VALUES("1222","51","ru","password","პაროლი","0");
INSERT INTO plain_text VALUES("1223","52","ru","fillsymbols","შეიყვანეთ სურათზე გამოსახული სიმბოლოები","0");
INSERT INTO plain_text VALUES("1224","53","ru","loginsystem","სისტემაში შესვლა","0");
INSERT INTO plain_text VALUES("1225","54","ru","fillusername","გთხოვთ შეავსოთ მომხმარებლის სახელი ველი","0");
INSERT INTO plain_text VALUES("1226","55","ru","fillpassword","გთხოვთ შეავსოთ პაროლის ველი","0");
INSERT INTO plain_text VALUES("1227","56","ru","fillsymbolsright","გთხოვთ სწორად შეავსოთ ფოტოზე გამოსახული სიმბოლოები","0");
INSERT INTO plain_text VALUES("1228","57","ru","webdeveloping","ვებ უზრუნველყოფა სტუდია 404","0");
INSERT INTO plain_text VALUES("1229","58","ru","allrequired","ყველა ველის შევსება სავალდებულოა","0");
INSERT INTO plain_text VALUES("1230","59","ru","userorpass","მომხმარებლის სახელი ან პაროლი არასწორია","0");
INSERT INTO plain_text VALUES("1231","60","ru","next","წინ","0");
INSERT INTO plain_text VALUES("1232","61","ru","prev","უკან","0");
INSERT INTO plain_text VALUES("1233","62","ru","last","ბოლო","0");
INSERT INTO plain_text VALUES("1234","63","ru","first","პირველი","0");
INSERT INTO plain_text VALUES("1235","64","ru","search","ძიება","0");
INSERT INTO plain_text VALUES("1236","65","ru","department","განყოფილება","0");
INSERT INTO plain_text VALUES("1237","66","ru","choose","აირჩიეთ","0");
INSERT INTO plain_text VALUES("1238","67","ru","chooseDep","გთხოვთ აირჩიოთ განყოფილება","0");
INSERT INTO plain_text VALUES("1239","68","ru","enter","შესვლა","0");
INSERT INTO plain_text VALUES("1240","69","ru","first_page","პირველი","0");
INSERT INTO plain_text VALUES("1241","70","ru","back_page","უკან","0");
INSERT INTO plain_text VALUES("1242","71","ru","next_page","შემდეგი","0");
INSERT INTO plain_text VALUES("1243","72","ru","last_page","ბოლო","0");
INSERT INTO plain_text VALUES("1244","73","ru","fillmobile","გთხოვთ შეავსოთ საკონტაქტო ნომრის ველი","0");
INSERT INTO plain_text VALUES("1245","74","ru","rights","უფლებები","0");
INSERT INTO plain_text VALUES("1246","75","ru","fillemail","გთხოვთ შეავსოთ ელ-ფოსტის ველი","0");
INSERT INTO plain_text VALUES("1247","76","ru","fillnamelname","გთხოვთ შეავსოთ სახელის და გვარის ველი","0");
INSERT INTO plain_text VALUES("1248","77","ru","additional","დამატებითი ინფორმაცია ","0");
INSERT INTO plain_text VALUES("1249","78","ru","filladditional","გთხოვთ შეავსოთ დამატებითი ინფორმაციის ველი","0");
INSERT INTO plain_text VALUES("1250","79","ru","clear","გასუფთავება","0");
INSERT INTO plain_text VALUES("1251","80","ru","requiredfields","გთხოვთ შეავსოთ *-ით აღნიშნული ველები","0");
INSERT INTO plain_text VALUES("1252","81","ru","checkMinimum","გთხოვთ მონიშნოთ მინიმუმ ერთი განყოფილება","0");
INSERT INTO plain_text VALUES("1253","82","ru","erroroccurred","მოხდა შეცდომა","0");
INSERT INTO plain_text VALUES("1254","83","ru","done","ოპერაცია წარმატებით განხორციელდა","0");
INSERT INTO plain_text VALUES("1255","84","ru","change_password","პაროლის შეცვლა","0");
INSERT INTO plain_text VALUES("1256","85","ru","old_password","ძველი პაროლი","0");
INSERT INTO plain_text VALUES("1257","86","ru","new_password","ახალი პაროლი","0");
INSERT INTO plain_text VALUES("1258","87","ru","comfirm_password","დაადასტურეთ პაროლი","0");
INSERT INTO plain_text VALUES("1259","88","ru","delete_elem","გნებავთ წაშალოთ ჩანაწერი","0");
INSERT INTO plain_text VALUES("1260","89","ru","close","დახურვა","0");
INSERT INTO plain_text VALUES("1261","90","ru","ip_address","IP მისამართი","0");
INSERT INTO plain_text VALUES("1262","91","ru","fillip","გთხოვთ შეავსოთ IP მისამართის ველი","0");
INSERT INTO plain_text VALUES("1263","92","ru","ip","IP მისამართი","0");
INSERT INTO plain_text VALUES("1264","93","ru","os","ოპერ. სისტემა","0");
INSERT INTO plain_text VALUES("1265","94","ru","browser","ბრაუზერი","0");
INSERT INTO plain_text VALUES("1266","95","ru","title","სათაური","0");
INSERT INTO plain_text VALUES("1267","96","ru","filltitle","გთხოვთ შეავსოთ სათაურის ველი","0");
INSERT INTO plain_text VALUES("1268","97","ru","text","ტექსტი","0");
INSERT INTO plain_text VALUES("1269","98","ru","filltext","გთხოვთ შეავსოთ ტექსტის ველი","0");
INSERT INTO plain_text VALUES("1270","99","ru","gotourl","ბმული","0");
INSERT INTO plain_text VALUES("1271","100","ru","fillgotourl","გთხოვთ შეავსოთ ბმულის ველი","0");
INSERT INTO plain_text VALUES("1272","101","ru","target","ბმულის გადასვლა","0");
INSERT INTO plain_text VALUES("1273","102","ru","filltarget","გთხოვთ შეავსოთ ბმულის გადასვლის ველი","0");
INSERT INTO plain_text VALUES("1274","103","ru","photo","ფოტო","0");
INSERT INTO plain_text VALUES("1275","104","ru","ka","ქართული","0");
INSERT INTO plain_text VALUES("1276","105","ru","en","ინგლისური","0");
INSERT INTO plain_text VALUES("1277","106","ru","move","გადაადგილება","0");
INSERT INTO plain_text VALUES("1278","107","ru","date","თარიღი","0");
INSERT INTO plain_text VALUES("1279","108","ru","meta_title","მეტა სათაური","0");
INSERT INTO plain_text VALUES("1280","109","ru","fillmeta_title","გთხოვთ შეავსოთ მეტა სათაური","0");
INSERT INTO plain_text VALUES("1281","110","ru","fillmeta_desc","გთხოვთ შეავსოთ მეტა აღწერის ველი","0");
INSERT INTO plain_text VALUES("1282","111","ru","meta_desc","მეტა აღწერა","0");
INSERT INTO plain_text VALUES("1283","112","ru","step","საფეხური","0");
INSERT INTO plain_text VALUES("1284","113","ru","fillstep","გთხოვთ აირციოთ საფეხურის ველი","0");
INSERT INTO plain_text VALUES("1285","114","ru","youtube_video","youtube ვიდეო","0");
INSERT INTO plain_text VALUES("1286","115","ru","fillyoutube_video","გთხოვთ შეავსოთ youtube ვიდეოს ველი","0");
INSERT INTO plain_text VALUES("1287","116","ru","filltype","გთხოვთ აირჩიოთ ტიპი","0");
INSERT INTO plain_text VALUES("1288","117","ru","pagetype","გვერდის ტიპი","0");
INSERT INTO plain_text VALUES("1289","118","ru","fillpagetype","გთხოვთ აირჩიოთ გვერდის ტიპი","0");
INSERT INTO plain_text VALUES("1290","119","ru","error_url","ბმულის ველში შეგიძლიათ გამოიყენოთ მხოლოდ ციფრებისა და ასოების კომბინაცია","0");
INSERT INTO plain_text VALUES("1291","120","ru","position","პოზ.","0");
INSERT INTO plain_text VALUES("1292","121","ru","fileAttach","ფაილის მიმაგრება (doc,docx,xls,xlsx,pdf,zip,rar)","0");
INSERT INTO plain_text VALUES("1293","122","ru","files","ფაილები","0");
INSERT INTO plain_text VALUES("1294","123","ru","attach","მიმაგრება","0");
INSERT INTO plain_text VALUES("1295","124","ru","showfiles","ფაილების ნახვა","0");
INSERT INTO plain_text VALUES("1296","125","ru","addgallery","გალერიის დამატება","0");
INSERT INTO plain_text VALUES("1297","126","ru","addphoto","ფოტოს დამატება","0");
INSERT INTO plain_text VALUES("1298","127","ru","cover","ქავერი","0");
INSERT INTO plain_text VALUES("1299","128","ru","newsCategory","სიახლის კატეგორია","0");
INSERT INTO plain_text VALUES("1300","129","ru","addnews","სიახლის დამატება","0");
INSERT INTO plain_text VALUES("1301","130","ru","short_text","მოკლე ტექსტი","0");
INSERT INTO plain_text VALUES("1302","131","ru","addcatalog","კატალოგის დამატება","0");
INSERT INTO plain_text VALUES("1303","132","ru","profesion","პროფესია","0");
INSERT INTO plain_text VALUES("1304","133","ru","fillprofesion","გთხოვთ შეავსოთ პროფესიის ველი","0");
INSERT INTO plain_text VALUES("1305","134","ru","dob","დაბადების თარიღი","0");
INSERT INTO plain_text VALUES("1306","135","ru","filldob","გთხოვთ შეავსოთ დაბადების თარიღის ველი","0");
INSERT INTO plain_text VALUES("1307","136","ru","bornplace","დაბადების ადგილი","0");
INSERT INTO plain_text VALUES("1308","137","ru","fillbornplace","გთხოვთ შეავსეთ დაბადების ადგილის ველი","0");
INSERT INTO plain_text VALUES("1309","138","ru","livingplace","საცხოვრებელი ადგილი","0");
INSERT INTO plain_text VALUES("1310","139","ru","filllivingplace","გთხოვთ შეავსოთ საცხოვრებელი ადგილის ველი","0");
INSERT INTO plain_text VALUES("1311","140","ru","phonenumber","საკონტაქტო ნომერი","0");
INSERT INTO plain_text VALUES("1312","141","ru","fillphonenumber","გთხოვთ შეავსოთ საკონტაქტო ნომერის ველი","0");
INSERT INTO plain_text VALUES("1313","142","ru","studentPortal","სტუდენტური პორტალი","0");
INSERT INTO plain_text VALUES("1314","143","ru","treinings","ტრენინგები","0");
INSERT INTO plain_text VALUES("1315","144","ru","certificate","სერთიფიკატები","0");
INSERT INTO plain_text VALUES("1316","145","ru","languages","ენები","0");
INSERT INTO plain_text VALUES("1317","146","ru","startjob","სამსახურის დაწყების თარიღი","0");
INSERT INTO plain_text VALUES("1318","147","ru","visibility","ხილვადობა","0");
INSERT INTO plain_text VALUES("1319","148","ru","visible","ხილვადი","0");
INSERT INTO plain_text VALUES("1320","149","ru","invisible","უხილავი","0");
INSERT INTO plain_text VALUES("1321","150","ru","shortbio","მოკლე ბიოგრაფია","0");
INSERT INTO plain_text VALUES("1322","151","ru","channelname","არხის სახელი","0");
INSERT INTO plain_text VALUES("1323","152","ru","fillchannel_name","გთხოვთ შეავსოთ არხის სახელი","0");
INSERT INTO plain_text VALUES("1324","153","ru","key","დეველოპერის გასაღები","0");
INSERT INTO plain_text VALUES("1325","154","ru","fillkey","გთხოვთ შეავსოთ დეველოპერის გასაღების ველი","0");
INSERT INTO plain_text VALUES("1326","155","ru","apppassword","აპლიკაციის პაროლი","0");
INSERT INTO plain_text VALUES("1327","156","ru","fillapppassword","გთხოვთ შეავსოთ აპლიკაციის პაროლი","0");
INSERT INTO plain_text VALUES("1328","157","ru","channel_link","არხის ბმული","0");
INSERT INTO plain_text VALUES("1329","158","ru","fillchannel_link","გთხოვთ შეავსოთ არხის ბმულის ველი","0");
INSERT INTO plain_text VALUES("1330","159","ru","category","კატეგორია","0");
INSERT INTO plain_text VALUES("1331","160","ru","channel","არხი","0");
INSERT INTO plain_text VALUES("1332","161","ru","desc","აღწერა","0");
INSERT INTO plain_text VALUES("1333","162","ru","tags","ტეგები","0");
INSERT INTO plain_text VALUES("1334","163","ru","filletags","გთხოვთ შეავსოთ ტეგების ველი, ტეგები გამოყავით მძიმით, შეიყვანეთ მინიმუმ 2 ტეგი","0");
INSERT INTO plain_text VALUES("1335","164","ru","video_file","ვიდეო ფაილი (ფორმატები: MOV,MPEG4,MP4,AVI,WMV,MPEGPS,FLV,3GPP,WebM)","0");
INSERT INTO plain_text VALUES("1336","165","ru","fillvideo_file","გთხოვთ ატვირთოთ ვიდეო","0");
INSERT INTO plain_text VALUES("1337","166","ru","chooseChannel","გთხოვთ აირჩიოთ არხი","0");
INSERT INTO plain_text VALUES("1338","167","ru","status","სტატუსი","0");
INSERT INTO plain_text VALUES("1339","168","ru","videoplayer","ვიდეო ფლეიერი","0");
INSERT INTO plain_text VALUES("1340","169","ru","filmAnimation","ფილმი & ანიმაცია","0");
INSERT INTO plain_text VALUES("1341","170","ru","auto","ავტო","0");
INSERT INTO plain_text VALUES("1342","171","ru","music","მუსიკა","0");
INSERT INTO plain_text VALUES("1343","172","ru","animal","ცხოველები","0");
INSERT INTO plain_text VALUES("1344","173","ru","sport","სპორტი","0");
INSERT INTO plain_text VALUES("1345","174","ru","travel","მოგზაურობა","0");
INSERT INTO plain_text VALUES("1346","175","ru","games","თამაშები","0");
INSERT INTO plain_text VALUES("1347","176","ru","comedy","კომედია","0");
INSERT INTO plain_text VALUES("1348","177","ru","entertaiment","გართობა","0");
INSERT INTO plain_text VALUES("1349","178","ru","education","განათლება","0");
INSERT INTO plain_text VALUES("1350","179","ru","technic","ტექნიკა","0");
INSERT INTO plain_text VALUES("1351","180","ru","movie","კინო","0");
INSERT INTO plain_text VALUES("1352","181","ru","url","ბმული","0");
INSERT INTO plain_text VALUES("1353","182","ru","banner","ბანერი (jpg,gif,png,jpeg,swf)","0");
INSERT INTO plain_text VALUES("1354","183","ru","youtubeCode","Youtube კოდი","0");
INSERT INTO plain_text VALUES("1355","184","ru","copy","დაკოპირება","0");
INSERT INTO plain_text VALUES("1356","185","ru","select","მონიშვნა","0");
INSERT INTO plain_text VALUES("1357","186","ru","sync","სინქრონიზაცია","0");
INSERT INTO plain_text VALUES("1358","187","ru","startpage","საწყისი გვერდი","0");
INSERT INTO plain_text VALUES("1359","188","ru","maxResult","მაქსიმალური რაოდენობა","0");
INSERT INTO plain_text VALUES("1360","189","ru","from","დან","0");
INSERT INTO plain_text VALUES("1361","190","ru","to","მდე","0");
INSERT INTO plain_text VALUES("1362","191","ru","quentity","რაოდენობა","0");
INSERT INTO plain_text VALUES("1363","192","ru","updating","განახლების პროცესშია","0");
INSERT INTO plain_text VALUES("1364","193","ru","uploaded","ატვირთულია","0");
INSERT INTO plain_text VALUES("1365","194","ru","inprogress","იტვირთება","0");
INSERT INTO plain_text VALUES("1366","195","ru","language","ენა","0");
INSERT INTO plain_text VALUES("1367","196","ru","vars","ცვლადი","0");
INSERT INTO plain_text VALUES("1368","197","ru","changevisibility","გნებავთ შეცვალოთ ხილვადობა","0");
INSERT INTO plain_text VALUES("1369","198","ru","yes","დიახ","0");
INSERT INTO plain_text VALUES("1370","199","ru","image","სურათი","0");
INSERT INTO plain_text VALUES("1371","200","ru","mainTitle","საქართველოს ბიზნესისა და მედიცინის აკადემია","0");
INSERT INTO plain_text VALUES("1372","201","ru","send","გაგზავნა","0");
INSERT INTO plain_text VALUES("1373","202","ru","name","სახელი","0");
INSERT INTO plain_text VALUES("1374","203","ru","message","შეტყობინება","0");
INSERT INTO plain_text VALUES("1375","204","ru","textus","მოგვწერეთ","0");
INSERT INTO plain_text VALUES("1376","205","ru","contact","კონტაქტი","0");
INSERT INTO plain_text VALUES("1377","206","ru","librery_text","ბიბლიოთეკა ტექსტი","0");
INSERT INTO plain_text VALUES("1378","207","ru","librery","ბიბლიოთეკა","0");
INSERT INTO plain_text VALUES("1379","208","ru","apoteka","აფტიაქი","0");
INSERT INTO plain_text VALUES("1380","209","ru","apoteka_text","აფტიაქი ტექსტი","0");
INSERT INTO plain_text VALUES("1381","210","ru","clinic_text","კლინიკა ტექსტი","0");
INSERT INTO plain_text VALUES("1382","211","ru","clinic","კლინიკა","0");
INSERT INTO plain_text VALUES("1383","212","ru","academy_text","აკადემია აკადემია აკადემი ტექსტი","0");
INSERT INTO plain_text VALUES("1384","213","ru","academy","აკადემია","0");
INSERT INTO plain_text VALUES("1385","214","ru","show_all_images","ყველა ფოტო","0");
INSERT INTO plain_text VALUES("1386","215","ru","error_description","ზოგჯერ თქვენ ცდილობთ ეწვიოთ ვებ-გვერდს რომელიც არ არსებობს, ან გადაიტანეს, ან ბმული შეცვალეს; ან ბმული შეცდომით დაბეჭდეთ; ან თქვენ დაკლიკეთ შეცდომით დაბეჭდილ ბმულზე; ამ და სხვა შეცდომების გამო ვხედავთ ამ გვერდს.","0");
INSERT INTO plain_text VALUES("1387","216","ru","error_msg","შეცდომა 404 გვერდი ვერ მოიძებნა","0");
INSERT INTO plain_text VALUES("1388","217","ru","variable","ცვლადი","0");
INSERT INTO plain_text VALUES("1389","218","ru","fillvariable","გთხოვთ შეავსოთ ცვლადის ველი","0");
INSERT INTO plain_text VALUES("1390","236","ru","actioned_idx","საინდენტიფიკაციო ობიექტი","0");
INSERT INTO plain_text VALUES("1391","235","ru","view_action","ადმინისტრატორის მოქმედება","0");
INSERT INTO plain_text VALUES("1392","233","ru","backuped","დარეზერვებულია","0");
INSERT INTO plain_text VALUES("1393","234","ru","admin","ადმინი","0");
INSERT INTO plain_text VALUES("1394","228","ru","makeBackup","დარეზერვება","0");
INSERT INTO plain_text VALUES("1395","229","ru","full","სრული","0");
INSERT INTO plain_text VALUES("1396","230","ru","files","ფაილები","0");
INSERT INTO plain_text VALUES("1397","231","ru","database","მონაცემთა ბაზა","0");
INSERT INTO plain_text VALUES("1398","232","ru","proccess","მიმდინარეობს","0");
INSERT INTO plain_text VALUES("1399","227","ru","chooseLanguage","აირჩიეთ ენა","0");
INSERT INTO plain_text VALUES("1400","226","ru","unsubscribe","გაუქმება","0");
INSERT INTO plain_text VALUES("1401","221","ru","question","კითხვა","0");
INSERT INTO plain_text VALUES("1402","222","ru","allpolls","ყველა გამოკითხვა","0");
INSERT INTO plain_text VALUES("1403","223","ru","poll","გამოკითხვა","0");
INSERT INTO plain_text VALUES("1404","224","ru","newsletter","სიახლეების გამოწერა","0");
INSERT INTO plain_text VALUES("1405","225","ru","subscribe","გამოწერა","0");
INSERT INTO plain_text VALUES("1406","220","ru","moreanswers","პასუხის დამატება","0");
INSERT INTO plain_text VALUES("1407","219","ru","answers","პასუხი","0");
INSERT INTO plain_text VALUES("1408","237","ru","data","მონაცემები","0");
INSERT INTO plain_text VALUES("1409","238","ru","chart","დიაგრამა","0");
INSERT INTO plain_text VALUES("1410","239","ru","created","შექმნილია","0");
INSERT INTO plain_text VALUES("1411","240","ru","get_chart","დიაგრამის ჩასმის კოდი","0");
INSERT INTO plain_text VALUES("1412","241","ru","UserBlocked","მომხმარებლის სახელი დაიბლოკა გთხოვთ სცადოთ მოგვიანებით","0");
INSERT INTO plain_text VALUES("1413","242","ru","noRight","თქვენ არ გაქვთ არსებული კონტენტის განახლების უფლება","0");



DROP TABLE system_ips;

CREATE TABLE `system_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO system_ips VALUES("1","გიორგი გვაზავა","176.73.234.42","1","0");
INSERT INTO system_ips VALUES("3","გიო ციბაძე","31.146.3.146","1","0");
INSERT INTO system_ips VALUES("4","ზვიად არძენაძე","176.73.25.67","1","0");
INSERT INTO system_ips VALUES("5","ვიო","195.54.87.05","1","0");
INSERT INTO system_ips VALUES("6","შალიკო","55588.877.554","1","0");
INSERT INTO system_ips VALUES("7","სამინისტრო","120.120.75.5","1","0");
INSERT INTO system_ips VALUES("8","test","55.78.98.2","1,17","0");



DROP TABLE system_logs;

CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8 NOT NULL,
  `os` varchar(100) CHARACTER SET utf8 NOT NULL,
  `browser` varchar(100) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL,
  `department` int(11) NOT NULL,
  `access` enum('1','2') CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=212 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO system_logs VALUES("34","1398861187","176.73.234.42","Windows 7","Chrome","1","4","1","1");
INSERT INTO system_logs VALUES("35","1398861522","176.73.234.42","Windows 7","Chrome","1","6","1","1");
INSERT INTO system_logs VALUES("36","1398861540","176.73.234.42","Windows 7","Chrome","1","8","1","1");
INSERT INTO system_logs VALUES("37","1398861836","176.73.234.42","Windows 7","Chrome","1","3","1","1");
INSERT INTO system_logs VALUES("38","1398861862","176.73.234.42","Windows 7","Chrome","1","4","1","1");
INSERT INTO system_logs VALUES("39","1398862174","176.73.234.42","Windows 7","Chrome","1","2","1","1");
INSERT INTO system_logs VALUES("40","1398932368","176.73.234.42","Windows 7","Chrome","1","7","1","1");
INSERT INTO system_logs VALUES("41","1398932714","176.73.234.42","Windows 7","Chrome","2","1","1","1");
INSERT INTO system_logs VALUES("42","1398933452","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("43","1398934054","176.73.234.42","Windows 7","Chrome","2","1","1","1");
INSERT INTO system_logs VALUES("44","1398934199","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("45","1398934592","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("46","1398934748","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("47","1398936707","176.73.234.42","Windows 7","Chrome","1","3","1","1");
INSERT INTO system_logs VALUES("48","1398936764","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("49","1398957528","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("50","1398971906","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("51","1398973618","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("52","1398973976","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("53","1398975356","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("54","1398978314","176.73.234.42","Windows 7","Chrome","7","1","1","1");
INSERT INTO system_logs VALUES("55","1398978523","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("56","1399018939","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("57","1399035295","176.73.234.42","Windows 7","Chrome","1","2","1","1");
INSERT INTO system_logs VALUES("58","1399051302","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("59","1399099945","176.73.234.42","Windows 7","Chrome","1","2","1","1");
INSERT INTO system_logs VALUES("60","1399189978","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("61","1399190028","176.73.234.42","Windows 7","Firefox","1","1","1","1");
INSERT INTO system_logs VALUES("62","1399190646","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("63","1399215329","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("64","1399215904","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("65","1399216169","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("66","1399216454","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("67","1399216722","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("68","1399217796","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("69","1399272562","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("70","1399287802","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("71","1399287817","31.146.3.146","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("72","1399288211","176.73.234.42","Windows 7","Chrome","1","2","1","1");
INSERT INTO system_logs VALUES("73","1399298452","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("74","1399371167","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("75","1399454454","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("76","1399461005","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("77","1399477509","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("78","1399563852","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("79","1399625442","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("80","1399712496","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("81","1399792462","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("82","1399792462","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("83","1399792489","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("84","1399817136","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("85","1399818887","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("86","1399875907","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("87","1399889755","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("88","1399983634","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("89","1399983680","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("90","1399984604","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("91","1399985169","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("92","1399986166","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("93","1400066610","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("94","1400072492","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("95","1400156827","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("96","1400182670","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("97","1400238546","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("98","1400316497","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("99","1400345882","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("100","1400408562","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("101","1400507665","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("102","1400669513","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("103","1400752457","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("104","1400781410","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("105","1400837169","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("106","1400956771","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("107","1401017695","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("108","1401105403","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("109","1401178835","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("110","1401209391","176.73.234.42","Windows 7","Chrome","1","2","1","1");
INSERT INTO system_logs VALUES("111","1401211343","176.73.234.42","Windows 7","Chrome","1","3","1","1");
INSERT INTO system_logs VALUES("112","1401211595","176.73.234.42","Windows 7","Chrome","1","7","1","1");
INSERT INTO system_logs VALUES("113","1401211910","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("114","1401212265","176.73.234.42","Windows 7","Chrome","1","5","1","1");
INSERT INTO system_logs VALUES("115","1401212418","176.73.234.42","Windows 7","Chrome","1","8","1","1");
INSERT INTO system_logs VALUES("116","1401215262","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("117","1401296227","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("118","1401401196","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("119","1401455794","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("120","1401556614","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("121","1401645666","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("122","1401718292","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("123","1401784619","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("124","1401969803","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("125","1402062008","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("126","1402168030","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("127","1402217725","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("128","1402241514","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("129","1402259734","176.73.234.42","Windows 7","Chrome","1","1","1","1");
INSERT INTO system_logs VALUES("130","1402260503","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("131","1402513115","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("132","1402567159","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("133","1402593104","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("134","1402682484","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("135","1402691057","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("136","1402849045","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("137","1402907665","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("138","1402910138","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("139","1402910300","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("140","1402944229","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("141","1402945640","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("142","1402990889","176.73.25.67","Windows 8.1","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("143","1403021641","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("144","1403074255","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("145","1403257181","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("146","1403284849","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("147","1403344602","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("148","1403363054","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("149","1403420804","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("150","1403436093","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("151","1403506482","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("152","1403518701","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("153","1403524448","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("154","1403694385","176.73.234.42","Windows XP","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("155","1403694552","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("156","1403707310","176.73.234.42","Windows XP","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("157","1403714412","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("158","1403785426","176.73.234.42","Windows XP","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("159","1403789825","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("160","1403853156","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("161","1403952347","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("162","1403963633","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("163","1403972514","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("164","1403983527","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("165","1403995187","176.73.234.42","Windows XP","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("166","1404029420","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("167","1404029630","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("168","1404033967","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("169","1404034100","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("170","1404043377","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("171","1404118184","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("172","1404121237","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("173","1404129906","176.73.234.42","Windows XP","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("174","1404145710","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("175","1404319803","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("176","1404458482","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("177","1404652090","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("178","1404743436","31.146.223.78","Windows 8.1","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("179","1404758203","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("180","1404758661","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("181","1404760163","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("182","1404820024","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("183","1404897879","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("184","1404936896","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("185","1404999283","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("186","1405072988","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("187","1405157073","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("188","1405243454","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("189","1405352550","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("190","1405409418","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("191","1405412856","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("192","1405424730","176.73.234.42","Windows 7","Chrome","10","9","1","0");
INSERT INTO system_logs VALUES("193","1405424855","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("194","1405430913","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("195","1405431152","213.131.43.82","Windows 7","Firefox","1","9","1","0");
INSERT INTO system_logs VALUES("196","1405516398","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("197","1405519890","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("198","1405532353","176.73.234.42","Windows 7","Chrome","1","9","1","1");
INSERT INTO system_logs VALUES("199","1405536850","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("200","1405537033","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("201","1405590412","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("202","1405666843","176.73.234.42","Windows 7","Chrome","1","9","1","0");
INSERT INTO system_logs VALUES("203","1405681875","176.73.234.42","Windows 7","Chrome","1","0","1","0");
INSERT INTO system_logs VALUES("204","1405683098","176.73.234.42","Windows 7","Chrome","1","0","1","0");
INSERT INTO system_logs VALUES("205","1405689269","176.73.234.42","Windows 7","Chrome","1","0","1","0");
INSERT INTO system_logs VALUES("206","1405717678","176.73.234.42","Windows 7","Chrome","1","0","1","0");
INSERT INTO system_logs VALUES("207","1405763652","176.73.234.42","Windows 7","Chrome","1","0","1","0");
INSERT INTO system_logs VALUES("208","1405852487","176.73.234.42","Windows 7","Chrome","1","0","1","0");
INSERT INTO system_logs VALUES("209","1405860310","176.73.234.42","Windows 7","Chrome","1","0","1","0");
INSERT INTO system_logs VALUES("210","1405862303","176.73.234.42","Windows 7","Chrome","1","0","1","0");
INSERT INTO system_logs VALUES("211","1405871294","176.73.234.42","Windows 7","Chrome","17","0","1","0");



DROP TABLE system_nav;

CREATE TABLE `system_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `icon_class` varchar(25) NOT NULL,
  `url` varchar(120) NOT NULL,
  `text` varchar(120) NOT NULL,
  `onclick` varchar(120) NOT NULL,
  `langs` varchar(2) NOT NULL,
  `position` int(11) NOT NULL,
  `visibility` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=utf8;

INSERT INTO system_nav VALUES("1","1","0","icon-home","ka/home","მთავარი","","ka","1","0","0");
INSERT INTO system_nav VALUES("2","1","0","icon-home","en/home","main","","en","1","0","0");
INSERT INTO system_nav VALUES("3","2","0","icon-man","javascript:void(0)","მომხმარებლები","","ka","2","0","0");
INSERT INTO system_nav VALUES("4","2","0","icon-man","javascript:void(0)","users","","en","2","0","0");
INSERT INTO system_nav VALUES("5","3","2","","ka/table/system_admin","სისტემის მომხმარებლები","","ka","1","0","0");
INSERT INTO system_nav VALUES("6","3","2","","en/table/system_admin","system users","","en","1","0","0");
INSERT INTO system_nav VALUES("7","4","2","","ka/table/projectusers","პროექტის მომხმარებლები","","ka","2","0","1");
INSERT INTO system_nav VALUES("8","4","2","","en/table/projectusers","project users","","en","2","0","1");
INSERT INTO system_nav VALUES("9","5","0","icon-lock","javascript:void(0)","IP მისამართები","","ka","3","0","0");
INSERT INTO system_nav VALUES("10","5","0","icon-lock","javascript:void(0)","IP addresses","","en","3","0","0");
INSERT INTO system_nav VALUES("11","6","5","","ka/table/systemipaddresses","სისტემის IP მისამართები","","ka","1","0","0");
INSERT INTO system_nav VALUES("12","6","5","","en/table/systemipaddresses","system IP addresses","","en","1","0","0");
INSERT INTO system_nav VALUES("13","7","5","","ka/table/projectipaddresses","პროექტის IP მისამართები","","ka","2","0","1");
INSERT INTO system_nav VALUES("14","7","5","","en/table/projectipaddresses","project IP address","","en","2","0","1");
INSERT INTO system_nav VALUES("15","8","0","icon-unlock","javascript:void(0)","ლოგები","","ka","4","0","0");
INSERT INTO system_nav VALUES("16","8","0","icon-unlock","javascript:void(0)","logs","","en","4","0","0");
INSERT INTO system_nav VALUES("17","9","8","","ka/table/systemlogs","სისტემის ლოგები","","ka","1","0","0");
INSERT INTO system_nav VALUES("18","9","8","","en/table/systemlogs","system logs","","en","1","0","0");
INSERT INTO system_nav VALUES("19","10","8","","ka/table/projectlogs","პროექტის ლოგები","","ka","2","0","1");
INSERT INTO system_nav VALUES("20","10","8","","en/table/projectlogs","project logs","","en","2","0","1");
INSERT INTO system_nav VALUES("21","11","0","icon-message","javascript:void(0)","შეტყობინებები","","ka","12","0","1");
INSERT INTO system_nav VALUES("22","11","0","icon-message","javascript:void(0)","messages","","en","12","0","1");
INSERT INTO system_nav VALUES("23","12","11","","ka/create","შექმნა","","ka","1","0","0");
INSERT INTO system_nav VALUES("24","12","11","","en/create","create","","en","1","0","0");
INSERT INTO system_nav VALUES("25","13","11","","ka/table/inbox","შემოსული","","ka","2","0","0");
INSERT INTO system_nav VALUES("26","13","11","","en/table/inbox","inbox","","en","2","0","0");
INSERT INTO system_nav VALUES("27","14","11","","ka/table/outbox","გასული","","ka","3","0","0");
INSERT INTO system_nav VALUES("28","14","11","","en/table/outbox","outbox","","en","3","0","0");
INSERT INTO system_nav VALUES("29","15","11","","ka/table/drafts","მონახაზი","","ka","4","0","0");
INSERT INTO system_nav VALUES("30","15","11","","en/table/drafts","drafts","","en","4","0","0");
INSERT INTO system_nav VALUES("31","16","11","","ka/table/deleted","წაშლილი","","ka","5","0","0");
INSERT INTO system_nav VALUES("32","16","11","","en/table/deleted","deleted","","en","5","0","0");
INSERT INTO system_nav VALUES("33","17","0","icon-page","javascript:void(0)","გვერდები","","ka","7","0","0");
INSERT INTO system_nav VALUES("34","17","0","icon-page","javascript:void(0)","pages","","en","7","0","0");
INSERT INTO system_nav VALUES("35","18","17","","ka/table/navigation","ნავიგაცია","","ka","1","0","0");
INSERT INTO system_nav VALUES("36","18","17","","en/table/navigation","navigation","","en","1","0","0");
INSERT INTO system_nav VALUES("37","19","17","","ka/table/catalogs","კატალოგი","","ka","5","0","0");
INSERT INTO system_nav VALUES("38","19","17","","en/table/catalogs","catalog","","en","5","0","0");
INSERT INTO system_nav VALUES("39","20","17","","ka/table/news","სიახლეები","","ka","3","0","0");
INSERT INTO system_nav VALUES("40","20","17","","en/table/news","news","","en","3","0","0");
INSERT INTO system_nav VALUES("41","21","17","","ka/table/gallery","გალერეა","","ka","4","0","0");
INSERT INTO system_nav VALUES("42","21","17","","en/table/gallery","gallery","","en","4","0","0");
INSERT INTO system_nav VALUES("43","22","17","","ka/table/text","ტექსტური","","ka","2","0","0");
INSERT INTO system_nav VALUES("44","22","17","","en/table/text","Text","","en","2","0","0");
INSERT INTO system_nav VALUES("45","23","17","","ka/table/invisiable","უხილავი ბმულები","","ka","6","0","0");
INSERT INTO system_nav VALUES("46","23","17","","en/table/invisiable","Invisiable links","","en","6","0","0");
INSERT INTO system_nav VALUES("47","24","17","","ka/table/othermodules","სხვა მოდულები","","ka","7","0","1");
INSERT INTO system_nav VALUES("48","24","17","","en/table/othermodules","other modules","","en","7","0","1");
INSERT INTO system_nav VALUES("49","25","0","icon-cart","javascript:void(0)","კალათა","","ka","8","0","1");
INSERT INTO system_nav VALUES("50","25","0","icon-cart","javascript:void(0)","cart","","en","8","0","1");
INSERT INTO system_nav VALUES("51","26","25","","ka/table/books","შეკვეთები","","ka","1","0","0");
INSERT INTO system_nav VALUES("52","26","25","","en/table/books","books","","en","1","0","0");
INSERT INTO system_nav VALUES("53","27","25","","ka/table/deletedbooks","წაშლილი შეკვეთები","","ka","2","0","0");
INSERT INTO system_nav VALUES("54","27","25","","en/table/deletedbooks","deleted books","","en","2","0","0");
INSERT INTO system_nav VALUES("55","28","25","","ka/table/unpayed","გადასახდელი ინვოისები","","ka","3","0","0");
INSERT INTO system_nav VALUES("56","28","25","","en/table/unpayed","unpayed invoices","","en","3","0","0");
INSERT INTO system_nav VALUES("57","29","25","","ka/table/payed","გადახდილი ინვოისები","","ka","4","0","0");
INSERT INTO system_nav VALUES("58","29","25","","en/table/payed","payed invoices","","en","4","0","0");
INSERT INTO system_nav VALUES("59","30","25","","ka/table/deletedinvoices","წაშლილი ინვოისები","","ka","5","0","0");
INSERT INTO system_nav VALUES("60","30","25","","en/table/deletedinvoices","deleted invoices","","en","5","0","0");
INSERT INTO system_nav VALUES("61","31","0","icon-filemanager","ka/table/filemanakar","ფაილის მენეჯერი","","ka","9","0","1");
INSERT INTO system_nav VALUES("62","31","0","icon-filemanager","en/table/filemanakar","file manager","","en","9","0","1");
INSERT INTO system_nav VALUES("63","32","0","icon-statistics","ka/table/statistics","სტატისტიკა","","ka","10","0","1");
INSERT INTO system_nav VALUES("64","32","0","icon-statistics","en/table/statistics","statistics","","en","10","0","1");
INSERT INTO system_nav VALUES("65","33","0","icon-cogs","ka/table/settings","პარამეტრები","","ka","11","0","1");
INSERT INTO system_nav VALUES("66","33","0","icon-cogs","en/table/settings","settings","","en","11","0","1");
INSERT INTO system_nav VALUES("67","34","0","icon-signout","ka/login","სისტემიდან გასვლა","","ka","18","0","0");
INSERT INTO system_nav VALUES("68","34","0","icon-signout","en/login","signout","","en","18","0","0");
INSERT INTO system_nav VALUES("69","0","2","","ka/add/system_admin","სისტემის მომხმარებლის დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("70","0","2","","en/add/system_admin","add system user","","en","0","1","0");
INSERT INTO system_nav VALUES("71","0","2","","ka/edit/system_admin","სისტემის მომხმარებლის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("72","0","2","","en/edit/system_admin","edit system users","","en","0","1","0");
INSERT INTO system_nav VALUES("75","0","5","","ka/add/systemipaddresses","IP მისამართის დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("76","0","5","","en/add/systemipaddresses","add IP Addresses","","en","0","1","0");
INSERT INTO system_nav VALUES("77","0","5","","ka/edit/systemipaddresses","IP მისამართის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("78","0","5","","en/edit/systemipaddresses","edit IP Addresses","","en","0","1","0");
INSERT INTO system_nav VALUES("79","35","0","icon-slide","ka/slide","სლაიდერი","","ka","6","0","0");
INSERT INTO system_nav VALUES("80","35","0","icon-slide","en/slide","Slider","","en","6","0","0");
INSERT INTO system_nav VALUES("81","0","35","","ka/add/slide","ფოტოს დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("82","0","35","","en/add/slide","ფოტოს დამატება","","en","0","1","0");
INSERT INTO system_nav VALUES("83","0","35","","ka/edit/slide","სლაიდერის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("84","0","35","","en/edit/slide","edit slider","","en","0","1","0");
INSERT INTO system_nav VALUES("85","0","17","","ka/add/navigation","ნავიგაციის დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("86","0","17","","en/add/navigation","Add navigation","","en","0","1","0");
INSERT INTO system_nav VALUES("89","0","17","","ka/edit/text","ტექსტური გვერდის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("87","0","17","","ka/edit/navigation","ნავიგაციის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("88","0","17","","en/edit/navigation","Edit navigation","","en","0","1","0");
INSERT INTO system_nav VALUES("90","0","17","","en/edit/text","Edit text page","","en","0","1","0");
INSERT INTO system_nav VALUES("91","33","17","","ka/table/gallery","გალერეა","","ka","0","1","0");
INSERT INTO system_nav VALUES("92","33","17","","en/table/gallery","გალერეა","","en","0","1","0");
INSERT INTO system_nav VALUES("93","0","17","","ka/add/gallery","გალერიის დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("94","0","17","","en/add/gallery","Add gallery","","en","0","1","0");
INSERT INTO system_nav VALUES("95","0","17","","ka/edit/gallery","გალერიის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("96","0","17","","en/edit/gallery","Edit gallery","","en","0","1","0");
INSERT INTO system_nav VALUES("97","0","17","","ka/table/photo","ფოტო","","ka","0","1","0");
INSERT INTO system_nav VALUES("98","0","17","","en/table/photo","Photo","","en","0","1","0");
INSERT INTO system_nav VALUES("99","0","17","","ka/add/photo","ფოტოს დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("100","0","17","","en/add/photo","Add photo","","en","0","1","0");
INSERT INTO system_nav VALUES("101","0","17","","ka/edit/photo","ფოტოს რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("102","0","17","","en/edit/photo","Edit photo","","en","0","1","0");
INSERT INTO system_nav VALUES("103","0","17","","ka/edit/news","სიახლის კატეგორიის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("104","0","17","","en/edit/news","Edit news category","","en","0","1","0");
INSERT INTO system_nav VALUES("105","0","17","","ka/table/newsItem","სიახლე","","ka","0","1","0");
INSERT INTO system_nav VALUES("106","0","17","","en/table/newsItem","News","","en","0","1","0");
INSERT INTO system_nav VALUES("107","0","17","","ka/add/newsItem","სიახლის დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("108","0","17","","en/add/newsItem","Add news","","en","0","1","0");
INSERT INTO system_nav VALUES("109","0","17","","ka/edit/newsItem","სიახლის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("110","0","17","","en/edit/newsItem","Edit news","","en","0","1","0");
INSERT INTO system_nav VALUES("111","0","17","","ka/table/categoryItem","კატალოგი","","ka","0","1","0");
INSERT INTO system_nav VALUES("112","0","17","","en/table/categoryItem","Catalog","","en","0","1","0");
INSERT INTO system_nav VALUES("113","0","17","","ka/add/categoryItem","კატეგორიის დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("114","0","17","","en/add/categoryItem","Add category","","ka","0","1","0");
INSERT INTO system_nav VALUES("115","0","17","","ka/edit/catalogs","კატალოგის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("116","0","17","","en/edit/catalogs","Edit catalog","","en","0","1","0");
INSERT INTO system_nav VALUES("117","0","17","","ka/edit/categoryItem","კატეგორიის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("118","0","17","","en/edit/categoryItem","Edit category","","en","0","1","0");
INSERT INTO system_nav VALUES("119","36","0","icon-youtube","javascript:void(0)","Youtube API","","ka","13","0","0");
INSERT INTO system_nav VALUES("120","36","0","icon-youtube","javascript:void(0)","Youtube API","","en","13","0","0");
INSERT INTO system_nav VALUES("121","0","36","","ka/table/youtubeChannels","Youtube არხი","","ka","1","0","0");
INSERT INTO system_nav VALUES("122","0","36","","en/table/youtubeChannels","Youtube channels","","en","1","0","0");
INSERT INTO system_nav VALUES("123","0","36","","ka/add/youtubeChannels","Youtube არხის დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("124","0","36","","en/add/youtubeChannels","Add youtube channels","","en","0","1","0");
INSERT INTO system_nav VALUES("128","0","36","","en/edit/youtubeChannels","Edit youtube channel","","en","0","1","0");
INSERT INTO system_nav VALUES("127","0","36","","ka/edit/youtubeChannels","Youtube არხის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("129","0","36","","ka/table/youtubeVideos","Youtube ვიდეო","","ka","1","0","0");
INSERT INTO system_nav VALUES("130","0","36","","en/table/youtubeVideos","Youtube video","","en","1","0","0");
INSERT INTO system_nav VALUES("131","0","36","","ka/add/youtubeVideos","ვიდეოს დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("132","0","36","","en/add/youtubeVideos","Add video","","en","0","1","0");
INSERT INTO system_nav VALUES("133","0","36","","en/edit/youtubeVideos","Edit youtube video","","en","0","1","0");
INSERT INTO system_nav VALUES("134","0","36","","ka/edit/youtubeVideos","Youtube ვიდეოს რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("135","37","0","icon-googleAnalitics","javascript:void(0)","Google analitics API","","ka","14","0","0");
INSERT INTO system_nav VALUES("136","37","0","icon-googleAnalitics","javascript:void(0)","Google analitics API","","en","14","0","0");
INSERT INTO system_nav VALUES("137","0","37","","ka/table/googleAnalitics","Google analitics","","ka","1","0","0");
INSERT INTO system_nav VALUES("138","0","37","","en/table/googleAnalitics","Google analitics","","en","1","0","0");
INSERT INTO system_nav VALUES("139","40","0","icon-banner","javascript:void(0)","ბანერების მართვა","","ka","16","0","0");
INSERT INTO system_nav VALUES("140","40","0","icon-banner","javascript:void(0)","Banner module","","en","16","0","0");
INSERT INTO system_nav VALUES("141","0","40","","ka/table/banners","ბანერები","","ka","1","0","0");
INSERT INTO system_nav VALUES("142","0","40","","en/table/banners","Banners","","en","1","0","0");
INSERT INTO system_nav VALUES("143","0","40","","ka/add/banners","ბანერის დამატება","","ka","0","1","0");
INSERT INTO system_nav VALUES("144","0","40","","en/add/banners","Add banner","","en","0","1","0");
INSERT INTO system_nav VALUES("145","0","40","","ka/edit/banners","ბანერის რედაქტირება","","ka","0","1","0");
INSERT INTO system_nav VALUES("146","0","40","","en/edit/banners","Edit banner","","en","0","1","0");
INSERT INTO system_nav VALUES("147","39","0","icon-language","javascript:void(0)","ენა","","ka","5","0","0");
INSERT INTO system_nav VALUES("148","39","0","icon-language","javascript:void(0)","Language","","en","5","0","0");
INSERT INTO system_nav VALUES("149","0","39","","ka/table/languages","ენები","","ka","1","0","0");
INSERT INTO system_nav VALUES("150","0","39","","en/table/languages","Languages","","en","1","0","0");
INSERT INTO system_nav VALUES("151","0","39","","ka/table/vars","ცვლადები","","ka","1","0","0");
INSERT INTO system_nav VALUES("152","0","39","","en/table/vars","Vars","","en","1","0","0");
INSERT INTO system_nav VALUES("153","0","39","","ka/add/languages","ენის დამატება","","ka","1","1","0");
INSERT INTO system_nav VALUES("154","0","39","","en/add/languages","Add language","","en","1","1","0");
INSERT INTO system_nav VALUES("155","0","39","","ka/edit/languages","ენის რედაქტირება","","ka","1","1","0");
INSERT INTO system_nav VALUES("156","0","39","","en/edit/languages","Edit language","","en","1","1","0");
INSERT INTO system_nav VALUES("157","0","39","","ka/add/vars","ცვლადის დამატება","","ka","1","1","0");
INSERT INTO system_nav VALUES("158","0","39","","en/add/vars","Add variable","","en","1","1","0");
INSERT INTO system_nav VALUES("159","0","39","","ka/edit/vars","ცვლადის რედაქტირება","","ka","1","1","0");
INSERT INTO system_nav VALUES("160","0","39","","en/edit/vars","Edit variable","","en","1","1","0");
INSERT INTO system_nav VALUES("161","38","0","icon-poll","javascript:void(0)","დიაგრამები & გამოკითხვა","","ka","15","0","0");
INSERT INTO system_nav VALUES("162","38","0","icon-poll","javascript:void(0)","Charts & Poll","","en","15","0","0");
INSERT INTO system_nav VALUES("163","0","38","","ka/table/polls","გამოკითხვის მოდული","","ka","1","0","0");
INSERT INTO system_nav VALUES("164","0","38","","en/table/polls","Poll plugin","","en","1","0","0");
INSERT INTO system_nav VALUES("165","0","38","","ka/add/polls","კითხვის დამატება","","ka","1","1","0");
INSERT INTO system_nav VALUES("166","0","38","","en/add/polls","Add questions","","en","1","1","0");
INSERT INTO system_nav VALUES("167","0","38","","ka/edit/polls","გამოკითხვის რედაქტირება","","ka","1","1","0");
INSERT INTO system_nav VALUES("168","0","38","","en/edit/polls","Edit poll","","en","1","1","0");
INSERT INTO system_nav VALUES("169","41","0","icon-backup","javascript:void(0)","სისტემის დარეზერვება","","ka","17","0","0");
INSERT INTO system_nav VALUES("170","41","0","icon-backup","javascript:void(0)","System backup","","en","17","0","0");
INSERT INTO system_nav VALUES("171","0","41","","ka/table/backup","რეზერვები","","ka","1","0","0");
INSERT INTO system_nav VALUES("172","0","41","","en/table/backup","backups","","en","1","0","0");
INSERT INTO system_nav VALUES("173","0","41","","ka/add/backup","დარეზერვება","","ka","1","1","0");
INSERT INTO system_nav VALUES("174","0","41","","en/add/backup","Make backup","","en","1","1","0");
INSERT INTO system_nav VALUES("175","0","2","","ka/table/actions","სისტემის ადმინის მოქმედებები","","ka","2","0","0");
INSERT INTO system_nav VALUES("176","0","2","","en/table/actions","System admin actions","","en","2","0","0");
INSERT INTO system_nav VALUES("177","0","38","","ka/table/charts","დიაგრამის მოდული","","ka","1","0","0");
INSERT INTO system_nav VALUES("178","0","38","","en/table/charts","Charts plugin","","en","1","0","0");
INSERT INTO system_nav VALUES("179","0","38","","ka/add/charts","დიაგრამის დამატება","","ka","1","1","0");
INSERT INTO system_nav VALUES("180","0","38","","en/add/charts","Add chart","","en","1","1","0");
INSERT INTO system_nav VALUES("181","0","38","","ka/edit/charts","დიაგრამის რედაქტირება","","ka","1","1","0");
INSERT INTO system_nav VALUES("182","0","38","","en/edit/charts","Edit chart","","en","1","1","0");



DROP TABLE website_actions;

CREATE TABLE `website_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `actioned_idx` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `request_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=155 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_actions VALUES("9","176.73.234.42","1","1405533981","ip","edit","5","http://akademqalaqiedu.ge/404@/ka/edit/systemipaddresses/5","0");
INSERT INTO website_actions VALUES("8","176.73.234.42","1","1405533602","ip","add","0","http://akademqalaqiedu.ge/404@/ka/add/systemipaddresses","0");
INSERT INTO website_actions VALUES("7","176.73.234.42","1","1405533328","users","delete","13","http://akademqalaqiedu.ge/404@/ka/table/system_admin","0");
INSERT INTO website_actions VALUES("10","176.73.234.42","1","1405534140","ip","add","0","http://akademqalaqiedu.ge/404@/ka/add/systemipaddresses","0");
INSERT INTO website_actions VALUES("11","176.73.234.42","1","1405534157","ip","delete","6,5","http://akademqalaqiedu.ge/404@/ka/table/systemipaddresses","0");
INSERT INTO website_actions VALUES("12","176.73.234.42","1","1405535185","logs","delete","198","http://akademqalaqiedu.ge/404@/ka/table/systemlogs","0");
INSERT INTO website_actions VALUES("13","176.73.234.42","1","1405536857","slide","move","9","http://akademqalaqiedu.ge/404@/ka/slide","0");
INSERT INTO website_actions VALUES("14","176.73.234.42","1","1405536975","slide","edit","9","http://akademqalaqiedu.ge/404@/ka/edit/slide/9","0");
INSERT INTO website_actions VALUES("15","176.73.234.42","1","1405540557","gallery","delete gallery","6","http://akademqalaqiedu.ge/404@/ka/table/gallery","0");
INSERT INTO website_actions VALUES("16","176.73.234.42","1","1405542680","banners","edit","8","http://akademqalaqiedu.ge/404@/ka/edit/banners/8","0");
INSERT INTO website_actions VALUES("17","176.73.234.42","1","1405542726","banners","edit","8","http://akademqalaqiedu.ge/404@/ka/edit/banners/8","0");
INSERT INTO website_actions VALUES("18","176.73.234.42","1","1405542774","banners","edit","8","http://akademqalaqiedu.ge/404@/ka/edit/banners/8","0");
INSERT INTO website_actions VALUES("19","176.73.234.42","1","1405666897","backup","add","0","http://akademqalaqiedu.ge/404@/ka/add/backup","0");
INSERT INTO website_actions VALUES("20","176.73.234.42","1","1405696447","users","add","0","http://mcla.404.ge/_adminpanel@/ka/add/system_admin","0");
INSERT INTO website_actions VALUES("21","176.73.234.42","1","1405696863","users","add","0","http://mcla.404.ge/_adminpanel@/ka/add/system_admin","0");
INSERT INTO website_actions VALUES("22","176.73.234.42","1","1405698664","users","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/system_admin/1","0");
INSERT INTO website_actions VALUES("23","176.73.234.42","1","1405699309","users","edit","1","http://mcla.404.ge/_adminpanel@/en/edit/system_admin/1","0");
INSERT INTO website_actions VALUES("24","176.73.234.42","1","1405699451","users","edit","1","http://mcla.404.ge/_adminpanel@/en/edit/system_admin/1","0");
INSERT INTO website_actions VALUES("25","176.73.234.42","1","1405699499","users","edit","1","http://mcla.404.ge/_adminpanel@/en/edit/system_admin/1","0");
INSERT INTO website_actions VALUES("26","176.73.234.42","1","1405699915","users","edit","15","http://mcla.404.ge/_adminpanel@/en/edit/system_admin/15","0");
INSERT INTO website_actions VALUES("27","176.73.234.42","1","1405701266","users","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/system_admin/1","0");
INSERT INTO website_actions VALUES("28","176.73.234.42","1","1405702218","users","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/system_admin/1","0");
INSERT INTO website_actions VALUES("29","176.73.234.42","1","1405702333","vars","add","0","http://mcla.404.ge/_adminpanel@/ka/add/vars","0");
INSERT INTO website_actions VALUES("30","176.73.234.42","1","1405702343","vars","add","0","http://mcla.404.ge/_adminpanel@/ka/add/vars","0");
INSERT INTO website_actions VALUES("31","176.73.234.42","1","1405718114","users","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/system_admin/1","0");
INSERT INTO website_actions VALUES("32","176.73.234.42","1","1405768808","vars","add","0","http://mcla.404.ge/_adminpanel@/ka/add/vars","0");
INSERT INTO website_actions VALUES("33","176.73.234.42","1","1405768829","vars","edit","238","http://mcla.404.ge/_adminpanel@/ka/edit/vars/238","0");
INSERT INTO website_actions VALUES("34","176.73.234.42","1","1405770935","navigation","add","0","http://mcla.404.ge/_adminpanel@/ka/add/navigation","0");
INSERT INTO website_actions VALUES("35","176.73.234.42","1","1405771525","navigation","move","2","http://mcla.404.ge/_adminpanel@/ajax/move.php?action=minus&idx=2&position=2&menu_type=1","0");
INSERT INTO website_actions VALUES("36","176.73.234.42","1","1405771541","navigation","move","2","http://mcla.404.ge/_adminpanel@/ajax/move.php?action=minus&idx=2&position=2&menu_type=1","0");
INSERT INTO website_actions VALUES("37","176.73.234.42","1","1405771619","navigation","move","2","http://mcla.404.ge/_adminpanel@/ajax/move.php?action=minus&idx=2&position=2&menu_type=1","0");
INSERT INTO website_actions VALUES("38","176.73.234.42","1","1405771662","navigation","move","2","http://mcla.404.ge/_adminpanel@/ajax/move.php?action=minus&idx=2&position=2&menu_type=1","0");
INSERT INTO website_actions VALUES("39","176.73.234.42","1","1405771795","navigation","move","2","http://mcla.404.ge/_adminpanel@/ajax/move.php?action=minus&idx=2&position=2&menu_type=1","0");
INSERT INTO website_actions VALUES("40","176.73.234.42","1","1405771799","navigation","move","2","http://mcla.404.ge/_adminpanel@/ajax/move.php?action=plus&idx=2&position=1&menu_type=1","0");
INSERT INTO website_actions VALUES("41","176.73.234.42","1","1405771856","navigation","move","2","http://mcla.404.ge/_adminpanel@/ajax/move.php?action=minus&idx=2&position=2&menu_type=1","0");
INSERT INTO website_actions VALUES("42","176.73.234.42","1","1405771869","navigation","move","2","http://mcla.404.ge/_adminpanel@/ajax/move.php?action=plus&idx=2&position=1&menu_type=1","0");
INSERT INTO website_actions VALUES("43","176.73.234.42","1","1405778186","chart","add","0","http://mcla.404.ge/_adminpanel@/ka/add/charts","0");
INSERT INTO website_actions VALUES("44","176.73.234.42","1","1405778423","chart","add","0","http://mcla.404.ge/_adminpanel@/ka/add/charts","0");
INSERT INTO website_actions VALUES("45","176.73.234.42","1","1405785817","vars","add","0","http://mcla.404.ge/_adminpanel@/ka/add/vars","0");
INSERT INTO website_actions VALUES("46","176.73.234.42","1","1405785835","vars","edit","239","http://mcla.404.ge/_adminpanel@/ka/edit/vars/239","0");
INSERT INTO website_actions VALUES("47","176.73.234.42","1","1405790578","charts","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/charts/1","0");
INSERT INTO website_actions VALUES("48","176.73.234.42","1","1405791021","charts","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/charts/1","0");
INSERT INTO website_actions VALUES("49","176.73.234.42","1","1405793881","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("50","176.73.234.42","1","1405793881","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("51","176.73.234.42","1","1405793881","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("52","176.73.234.42","1","1405793900","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("53","176.73.234.42","1","1405793900","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("54","176.73.234.42","1","1405793900","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("55","176.73.234.42","1","1405794028","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("56","176.73.234.42","1","1405794028","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("57","176.73.234.42","1","1405794028","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("58","176.73.234.42","1","1405794711","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("59","176.73.234.42","1","1405794711","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("60","176.73.234.42","1","1405794711","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("61","176.73.234.42","1","1405794817","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("62","176.73.234.42","1","1405794817","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("63","176.73.234.42","1","1405794817","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("64","176.73.234.42","1","1405795081","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("65","176.73.234.42","1","1405795081","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("66","176.73.234.42","1","1405795081","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("67","176.73.234.42","1","1405795231","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("68","176.73.234.42","1","1405795231","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("69","176.73.234.42","1","1405795231","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("70","176.73.234.42","1","1405795329","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("71","176.73.234.42","1","1405795329","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("72","176.73.234.42","1","1405795329","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("73","176.73.234.42","1","1405795725","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("74","176.73.234.42","1","1405795725","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("75","176.73.234.42","1","1405795725","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("76","176.73.234.42","1","1405795806","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("77","176.73.234.42","1","1405795806","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("78","176.73.234.42","1","1405795806","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("79","176.73.234.42","1","1405795862","navigation","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/navigation/2","0");
INSERT INTO website_actions VALUES("80","176.73.234.42","1","1405796415","navigation","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/navigation/2","0");
INSERT INTO website_actions VALUES("81","176.73.234.42","1","1405796509","navigation","add","0","http://mcla.404.ge/_adminpanel@/ka/add/navigation","0");
INSERT INTO website_actions VALUES("82","176.73.234.42","1","1405796832","text","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/text/3","0");
INSERT INTO website_actions VALUES("83","176.73.234.42","1","1405796832","text","edti","3","http://mcla.404.ge/_adminpanel@/ka/edit/text/3","0");
INSERT INTO website_actions VALUES("84","176.73.234.42","1","1405796832","text","edti","3","http://mcla.404.ge/_adminpanel@/ka/edit/text/3","0");
INSERT INTO website_actions VALUES("85","176.73.234.42","1","1405797350","chart","add","0","http://mcla.404.ge/_adminpanel@/ka/add/charts","0");
INSERT INTO website_actions VALUES("86","176.73.234.42","1","1405797458","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("87","176.73.234.42","1","1405797458","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("88","176.73.234.42","1","1405797458","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("89","176.73.234.42","1","1405797865","charts","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/charts/2","0");
INSERT INTO website_actions VALUES("90","176.73.234.42","1","1405797971","charts","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/charts/2","0");
INSERT INTO website_actions VALUES("91","176.73.234.42","1","1405799814","chart","add","0","http://mcla.404.ge/_adminpanel@/ka/add/charts","0");
INSERT INTO website_actions VALUES("92","176.73.234.42","1","1405800018","text","edit","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("93","176.73.234.42","1","1405800018","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("94","176.73.234.42","1","1405800018","text","edti","2","http://mcla.404.ge/_adminpanel@/ka/edit/text/2","0");
INSERT INTO website_actions VALUES("95","176.73.234.42","1","1405800175","charts","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/charts/3","0");
INSERT INTO website_actions VALUES("96","176.73.234.42","1","1405800543","charts","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/charts/3","0");
INSERT INTO website_actions VALUES("97","176.73.234.42","1","1405800797","charts","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/charts/3","0");
INSERT INTO website_actions VALUES("98","176.73.234.42","1","1405800831","charts","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/charts/3","0");
INSERT INTO website_actions VALUES("99","176.73.234.42","1","1405801011","charts","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/charts/3","0");
INSERT INTO website_actions VALUES("100","176.73.234.42","1","1405801061","charts","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/charts/3","0");
INSERT INTO website_actions VALUES("101","176.73.234.42","1","1405801488","charts","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/charts/3","0");
INSERT INTO website_actions VALUES("102","176.73.234.42","1","1405801617","charts","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/charts/3","0");
INSERT INTO website_actions VALUES("103","176.73.234.42","1","1405802407","vars","add","0","http://mcla.404.ge/_adminpanel@/ka/add/vars","0");
INSERT INTO website_actions VALUES("104","176.73.234.42","1","1405802432","vars","edit","240","http://mcla.404.ge/_adminpanel@/ka/edit/vars/240","0");
INSERT INTO website_actions VALUES("105","176.73.234.42","1","1405802475","text","edit","3","http://mcla.404.ge/_adminpanel@/ka/edit/text/3","0");
INSERT INTO website_actions VALUES("106","176.73.234.42","1","1405802475","text","edti","3","http://mcla.404.ge/_adminpanel@/ka/edit/text/3","0");
INSERT INTO website_actions VALUES("107","176.73.234.42","1","1405802475","text","edti","3","http://mcla.404.ge/_adminpanel@/ka/edit/text/3","0");
INSERT INTO website_actions VALUES("108","176.73.234.42","1","1405802771","charts","delete","2","http://mcla.404.ge/_adminpanel@/ka/table/charts","0");
INSERT INTO website_actions VALUES("109","176.73.234.42","1","1405854297","banners","add","0","http://mcla.404.ge/_adminpanel@/ka/add/banners","0");
INSERT INTO website_actions VALUES("110","176.73.234.42","1","1405856055","banners","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/banners/1","0");
INSERT INTO website_actions VALUES("111","176.73.234.42","1","1405856170","banners","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/banners/1","0");
INSERT INTO website_actions VALUES("112","176.73.234.42","1","1405856211","banners","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/banners/1","0");
INSERT INTO website_actions VALUES("113","176.73.234.42","1","1405856380","banners","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/banners/1","0");
INSERT INTO website_actions VALUES("114","176.73.234.42","1","1405856549","banners","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/banners/1","0");
INSERT INTO website_actions VALUES("115","176.73.234.42","1","1405856599","banners","delete","1","http://mcla.404.ge/_adminpanel@/ka/table/banners","0");
INSERT INTO website_actions VALUES("116","176.73.234.42","1","1405856649","banners","add","0","http://mcla.404.ge/_adminpanel@/ka/add/banners","0");
INSERT INTO website_actions VALUES("117","176.73.234.42","1","1405856671","banners","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/banners/1","0");
INSERT INTO website_actions VALUES("118","176.73.234.42","1","1405856699","banners","edit","1","http://mcla.404.ge/_adminpanel@/ka/edit/banners/1","0");
INSERT INTO website_actions VALUES("119","176.73.234.42","1","1405857179","navigation","add","0","http://mcla.404.ge/_adminpanel@/ka/add/navigation","0");
INSERT INTO website_actions VALUES("120","176.73.234.42","1","1405860369","vars","add","0","http://mcla.404.ge/_adminpanel@/ka/add/vars","0");
INSERT INTO website_actions VALUES("121","176.73.234.42","1","1405860404","vars","edit","241","http://mcla.404.ge/_adminpanel@/ka/edit/vars/241","0");
INSERT INTO website_actions VALUES("122","176.73.234.42","1","1405866387","users","delete","1","http://mcla.404.ge/_adminpanel@/ka/table/system_admin","0");
INSERT INTO website_actions VALUES("123","176.73.234.42","1","1405866393","users","delete","1","http://mcla.404.ge/_adminpanel@/ka/table/system_admin","0");
INSERT INTO website_actions VALUES("124","176.73.234.42","1","1405866497","users","add","0","http://mcla.404.ge/_adminpanel@/ka/add/system_admin","0");
INSERT INTO website_actions VALUES("125","176.73.234.42","1","1405866531","users","add","0","http://mcla.404.ge/_adminpanel@/ka/add/system_admin","0");
INSERT INTO website_actions VALUES("126","176.73.234.42","1","1405866709","users","add","0","http://mcla.404.ge/_adminpanel@/ka/add/system_admin","0");
INSERT INTO website_actions VALUES("127","176.73.234.42","1","1405871259","ip","add","0","http://mcla.404.ge/_adminpanel@/ka/add/systemipaddresses","0");
INSERT INTO website_actions VALUES("128","176.73.234.42","17","1405871321","ip","add","0","http://mcla.404.ge/_adminpanel@/ka/add/systemipaddresses","0");
INSERT INTO website_actions VALUES("129","176.73.234.42","17","1405874588","vars","add","0","http://mcla.404.ge/_adminpanel@/ka/add/vars","0");
INSERT INTO website_actions VALUES("130","176.73.234.42","17","1405874615","vars","edit","242","http://mcla.404.ge/_adminpanel@/ka/edit/vars/242","0");
INSERT INTO website_actions VALUES("131","176.73.234.42","17","1405877341","language","add","0","http://mcla.404.ge/_adminpanel@/ka/add/languages","0");
INSERT INTO website_actions VALUES("132","176.73.234.42","17","1405877400","language","visibility change","10","http://mcla.404.ge/_adminpanel@/ka/table/languages","0");
INSERT INTO website_actions VALUES("133","176.73.234.42","17","1405878258","language","visibility change","10","http://mcla.404.ge/_adminpanel@/ka/table/languages","0");
INSERT INTO website_actions VALUES("134","176.73.234.42","17","1405878282","language","visibility change","7","http://mcla.404.ge/_adminpanel@/ka/table/languages","0");
INSERT INTO website_actions VALUES("135","176.73.234.42","17","1405878746","language","visibility change","10","http://mcla.404.ge/_adminpanel@/ka/table/languages","0");
INSERT INTO website_actions VALUES("136","176.73.234.42","17","1405878777","slide","delete","9","http://mcla.404.ge/_adminpanel@/ka/slide","0");
INSERT INTO website_actions VALUES("137","176.73.234.42","17","1405878782","slide","delete","7","http://mcla.404.ge/_adminpanel@/ka/slide","0");
INSERT INTO website_actions VALUES("138","176.73.234.42","17","1405879856","slide","add","0","http://mcla.404.ge/_adminpanel@/ka/add/slide","0");
INSERT INTO website_actions VALUES("139","176.73.234.42","17","1405882674","navigation","add","0","http://mcla.404.ge/_adminpanel@/ka/add/navigation","0");
INSERT INTO website_actions VALUES("140","176.73.234.42","17","1405883809","navigation","add","0","http://mcla.404.ge/_adminpanel@/ka/add/navigation","0");
INSERT INTO website_actions VALUES("141","176.73.234.42","17","1405886281","news","add news item","0","http://mcla.404.ge/_adminpanel@/ka/add/newsItem/1","0");
INSERT INTO website_actions VALUES("142","176.73.234.42","17","1405888320","news","add news item","0","http://mcla.404.ge/_adminpanel@/ka/add/newsItem/1","0");
INSERT INTO website_actions VALUES("143","176.73.234.42","17","1405888720","navigation","add","0","http://mcla.404.ge/_adminpanel@/ka/add/navigation","0");
INSERT INTO website_actions VALUES("144","176.73.234.42","17","1405888737","navigation","add","0","http://mcla.404.ge/_adminpanel@/ka/add/navigation","0");
INSERT INTO website_actions VALUES("145","176.73.234.42","17","1405888896","gallery","add gallery","0","http://mcla.404.ge/_adminpanel@/ka/add/gallery","0");
INSERT INTO website_actions VALUES("146","176.73.234.42","17","1405889248","gallery","add gallery","0","http://mcla.404.ge/_adminpanel@/ka/add/gallery","0");
INSERT INTO website_actions VALUES("147","176.73.234.42","17","1405889798","photo","add","0","http://mcla.404.ge/_adminpanel@/ka/add/photo/2","0");
INSERT INTO website_actions VALUES("148","176.73.234.42","17","1405890234","navigation","add","0","http://mcla.404.ge/_adminpanel@/ka/add/navigation","0");
INSERT INTO website_actions VALUES("149","176.73.234.42","17","1405891173","catalog","add catalog item","0","http://mcla.404.ge/_adminpanel@/ka/add/categoryItem/1","0");
INSERT INTO website_actions VALUES("150","176.73.234.42","17","1405893009","polls","add","0","http://mcla.404.ge/_adminpanel@/ka/add/polls","0");
INSERT INTO website_actions VALUES("151","176.73.234.42","17","1405895527","polls","add","0","http://mcla.404.ge/_adminpanel@/ka/add/polls","0");
INSERT INTO website_actions VALUES("152","176.73.234.42","17","1405895897","chart","add","0","http://mcla.404.ge/_adminpanel@/ka/add/charts","0");
INSERT INTO website_actions VALUES("153","176.73.234.42","17","1405896226","banners","add","0","http://mcla.404.ge/_adminpanel@/ka/add/banners","0");
INSERT INTO website_actions VALUES("154","176.73.234.42","17","1405896472","backup","add","0","http://mcla.404.ge/_adminpanel@/ka/add/backup","0");



DROP TABLE website_backup;

CREATE TABLE `website_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('full','files','database') COLLATE utf8_unicode_ci NOT NULL,
  `croned` int(11) NOT NULL,
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_backup VALUES("4","1405666897","1405666897","1405784583.zip","database","1","0","0");
INSERT INTO website_backup VALUES("3","1405424316","1405424316","1405424343.zip","full","1","0","0");
INSERT INTO website_backup VALUES("5","1405896472","1405896472","","database","0","1,17","0");



DROP TABLE website_banners;

CREATE TABLE `website_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `banner_type` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `img_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_banners VALUES("13","1","1405896226","ტესტ","img","banner_1405896226.jpg","ტესტ","1","1","ka","0");
INSERT INTO website_banners VALUES("14","1","1405896226","ტესტ","img","banner_1405896226.jpg","ტესტ","1","1","en","0");
INSERT INTO website_banners VALUES("15","1","1405896226","ტესტ","img","banner_1405896226.jpg","ტესტ","1","1","ru","0");



DROP TABLE website_catalogs;

CREATE TABLE `website_catalogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ka',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=190 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_catalogs VALUES("187","1","1405890234","თანამშრომლები","ka","0");
INSERT INTO website_catalogs VALUES("188","1","1405890234","თანამშრომლები","en","0");
INSERT INTO website_catalogs VALUES("189","1","1405890234","თანამშრომლები","ru","0");



DROP TABLE website_catalogs_attachment;

CREATE TABLE `website_catalogs_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `connect_id` int(11) NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ka',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=190 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_catalogs_attachment VALUES("187","1","8","1","ka");
INSERT INTO website_catalogs_attachment VALUES("188","1","8","1","en");
INSERT INTO website_catalogs_attachment VALUES("189","1","8","1","ru");



DROP TABLE website_catalogs_items;

CREATE TABLE `website_catalogs_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startjob` int(11) NOT NULL,
  `idx` int(11) NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `namelname` varchar(255) NOT NULL,
  `profesion` varchar(255) NOT NULL,
  `dob` int(11) NOT NULL,
  `bornplace` varchar(255) NOT NULL,
  `livingplace` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `shortbio` varchar(255) NOT NULL,
  `education` varchar(255) NOT NULL,
  `treinings` varchar(255) NOT NULL,
  `certificate` varchar(255) NOT NULL,
  `languages` varchar(255) NOT NULL,
  `langs` varchar(2) NOT NULL DEFAULT 'ka',
  `access_admins` varchar(120) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

INSERT INTO website_catalogs_items VALUES("48","1405886400","1","1","ტესტ მასწავლებელი","იოო","1405886400","ფიო","ასდ","5669955","gioaxlouri@gmail.com","<p>asdkj</p>","<p>asdjkas</p>","<p>askdj</p>","<p>kjkj</p>","<p>kjkj</p>","ru","1","0");
INSERT INTO website_catalogs_items VALUES("46","1405886400","1","1","ტესტ მასწავლებელი","იოო","1405886400","ფიო","ასდ","5669955","gioaxlouri@gmail.com","<p>asdkj</p>","<p>asdjkas</p>","<p>askdj</p>","<p>kjkj</p>","<p>kjkj</p>","ka","1","0");
INSERT INTO website_catalogs_items VALUES("47","1405886400","1","1","ტესტ მასწავლებელი","იოო","1405886400","ფიო","ასდ","5669955","gioaxlouri@gmail.com","<p>asdkj</p>","<p>asdjkas</p>","<p>askdj</p>","<p>kjkj</p>","<p>kjkj</p>","en","1","0");



DROP TABLE website_charts;

CREATE TABLE `website_charts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `chart_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `chart_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `chart_file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `create_status` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_charts VALUES("11","1","1405895897","ახალი დიაგრამა","oil_reserves","1405895897_ka.html","inprogress","ka","1","0");
INSERT INTO website_charts VALUES("12","1","1405895897","ახალი დიაგრამა","oil_reserves","1405895897_en.html","inprogress","en","1","0");
INSERT INTO website_charts VALUES("13","1","1405895897","ახალი დიაგრამა","oil_reserves","1405895897_ru.html","inprogress","ru","1","0");



DROP TABLE website_charts_items;

CREATE TABLE `website_charts_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `chart_idx` int(11) NOT NULL,
  `label_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `label_value` int(255) NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_charts_items VALUES("37","1","1","შალვა","55","ru","0");
INSERT INTO website_charts_items VALUES("36","1","1","დათო","350","ru","0");
INSERT INTO website_charts_items VALUES("35","1","1","გიო","550","ru","0");
INSERT INTO website_charts_items VALUES("34","1","1","შალვა","55","en","0");
INSERT INTO website_charts_items VALUES("33","1","1","დათო","350","en","0");
INSERT INTO website_charts_items VALUES("32","1","1","გიო","550","en","0");
INSERT INTO website_charts_items VALUES("31","1","1","შალვა","55","ka","0");
INSERT INTO website_charts_items VALUES("30","1","1","დათო","350","ka","0");
INSERT INTO website_charts_items VALUES("29","1","1","გიო","550","ka","0");



DROP TABLE website_croned;

CREATE TABLE `website_croned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_croned VALUES("1","newsletter","1405895404");
INSERT INTO website_croned VALUES("2","youtubeUpload","1405666805");
INSERT INTO website_croned VALUES("3","youtubeEdit","1405666804");
INSERT INTO website_croned VALUES("4","youtubeDelete","1405666805");
INSERT INTO website_croned VALUES("5","backup","1405896484");
INSERT INTO website_croned VALUES("6","create_chart","1405895763");
INSERT INTO website_croned VALUES("7","unblock_users","1405896303");



DROP TABLE website_files;

CREATE TABLE `website_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_idx` int(11) NOT NULL,
  `page_type` varchar(120) NOT NULL,
  `outname` text NOT NULL,
  `filename` text NOT NULL,
  `filetype` text NOT NULL,
  `langs` varchar(2) NOT NULL DEFAULT 'ka',
  `departments` varchar(255) NOT NULL,
  `admin_permission` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;




DROP TABLE website_gallery;

CREATE TABLE `website_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `langs` varchar(2) NOT NULL,
  `access_admins` varchar(120) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

INSERT INTO website_gallery VALUES("63","1","1405888896","იოო","ka","1","0");
INSERT INTO website_gallery VALUES("64","1","1405888896","იოო","en","1","0");
INSERT INTO website_gallery VALUES("65","1","1405888896","იოო","ru","1","0");
INSERT INTO website_gallery VALUES("66","2","1405889248","ტესტ","ka","1,17","0");
INSERT INTO website_gallery VALUES("67","2","1405889248","ტესტ","en","1,17","0");
INSERT INTO website_gallery VALUES("68","2","1405889248","ტესტ","ru","1,17","0");



DROP TABLE website_gallery_attachment;

CREATE TABLE `website_gallery_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `connect_id` int(11) NOT NULL,
  `gallery_idx` int(11) NOT NULL,
  `langs` varchar(2) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

INSERT INTO website_gallery_attachment VALUES("65","2","0","2","ru","gallery");
INSERT INTO website_gallery_attachment VALUES("64","2","0","2","en","gallery");
INSERT INTO website_gallery_attachment VALUES("63","2","0","2","ka","gallery");
INSERT INTO website_gallery_attachment VALUES("62","1","0","1","ru","gallery");
INSERT INTO website_gallery_attachment VALUES("61","1","0","1","en","gallery");
INSERT INTO website_gallery_attachment VALUES("60","1","0","1","ka","gallery");



DROP TABLE website_gallery_photos;

CREATE TABLE `website_gallery_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `photo` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `cover` int(11) NOT NULL,
  `langs` varchar(2) NOT NULL,
  `position` int(11) NOT NULL,
  `access_admins` varchar(120) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;

INSERT INTO website_gallery_photos VALUES("123","1","2","1405889798","gallery_1405889798.png","ჯჰჯ","<p>ჯასჰდკჯასჰდკჯასჰდკჯ აკჯსდ ჰკჯასდ ჰკჯასდჯკ&nbsp;</p>","0","ka","1","1","0");
INSERT INTO website_gallery_photos VALUES("124","1","2","1405889798","gallery_1405889798.png","ჯჰჯ","<p>ჯასჰდკჯასჰდკჯასჰდკჯ აკჯსდ ჰკჯასდ ჰკჯასდჯკ&nbsp;</p>","0","en","1","1","0");
INSERT INTO website_gallery_photos VALUES("125","1","2","1405889798","gallery_1405889798.png","ჯჰჯ","<p>ჯასჰდკჯასჰდკჯასჰდკჯ აკჯსდ ჰკჯასდ ჰკჯასდჯკ&nbsp;</p>","0","ru","1","1","0");



DROP TABLE website_languages;

CREATE TABLE `website_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `outname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `visibility` int(11) NOT NULL,
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_languages VALUES("1","ქართული","ka","","0","1","0");
INSERT INTO website_languages VALUES("2","English","en","","0","1","0");
INSERT INTO website_languages VALUES("10","русский","ru","","0","1,17","0");



DROP TABLE website_menu;

CREATE TABLE `website_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `idx` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_desc` varchar(255) NOT NULL,
  `title` varchar(120) NOT NULL,
  `text` text NOT NULL,
  `url` text NOT NULL,
  `main_photo` varchar(255) NOT NULL,
  `video` varchar(255) NOT NULL,
  `menu_type` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `poll_id` int(11) DEFAULT NULL,
  `langs` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `visibility` int(11) NOT NULL,
  `departments` varchar(250) NOT NULL,
  `access_admins` varchar(120) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=646 DEFAULT CHARSET=utf8;

INSERT INTO website_menu VALUES("1","0","1","0","მთავარი","მთავარი აღწერა","მთავარი","<p>მთავარი მთავარი</p>","ka/home","","","1","plugin","0","ka","1","0","college","1","0");
INSERT INTO website_menu VALUES("2","0","1","0","Home","Home Home","Home","<p>Home</p>","en/home","","","1","plugin","0","en","1","0","college","1","0");
INSERT INTO website_menu VALUES("633","1405770935","2","0","ტექსტური გვერდი","ტექსტური გვერდი","ტექსტური გვერდი","<p><iframe class=\"my_chart\" style=\"overflow: hidden;\" src=\"http://www.mcla.404.ge//_charts/1405778423_ka.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\n<p><iframe class=\"my_chart\" src=\"http://www.mcla.404.ge//_charts/1405797350_ka.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\n<p><iframe class=\"my_chart\" src=\"http://www.mcla.404.ge/_charts/1405799814_ka.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>","ru/text","","","1","text","0","ru","2","0","","1","0");
INSERT INTO website_menu VALUES("632","1405796509","3","0","youtube ტესტ ვიდეო","youtube ტესტ ვიდეო","youtube ტესტ ვიდეო","<p><iframe src=\"//www.youtube.com/embed/vOeR0y6HwsA\" width=\"600\" height=\"338\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\n<p><iframe class=\"my_chart\" src=\"http://www.mcla.404.ge/_charts/1405799814_ka.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>","ru/youtube","","","1","text","0","ru","3","0","","1","0");
INSERT INTO website_menu VALUES("630","0","1","0","მთავარი","მთავარი აღწერა","მთავარი","<p>მთავარი მთავარი</p>","ru/home","","","1","plugin","0","ru","1","0","college","1","0");
INSERT INTO website_menu VALUES("631","1405857179","4","0","საიტის რუკა","საიტის რუკა","საიტის რუკა","<p>საიტის რუკა</p>","ru/sitemap","","","1","plugin","0","ru","4","1","","1","0");
INSERT INTO website_menu VALUES("628","1405857179","4","0","საიტის რუკა","საიტის რუკა","საიტის რუკა","<p>საიტის რუკა</p>","ka/sitemap","","","1","plugin","","ka","4","1","","1","0");
INSERT INTO website_menu VALUES("629","1405857179","4","0","საიტის რუკა","საიტის რუკა","საიტის რუკა","<p>საიტის რუკა</p>","en/sitemap","","","1","plugin","","en","4","1","","1","0");
INSERT INTO website_menu VALUES("627","1405796509","3","0","youtube text video","youtube text video","youtube text video","<p><iframe src=\"//www.youtube.com/embed/vOeR0y6HwsA\" width=\"600\" height=\"338\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>","en/youtube","","","1","text","","en","3","0","","1","0");
INSERT INTO website_menu VALUES("626","1405796509","3","0","youtube ტესტ ვიდეო","youtube ტესტ ვიდეო","youtube ტესტ ვიდეო","<p><iframe src=\"//www.youtube.com/embed/vOeR0y6HwsA\" width=\"600\" height=\"338\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\n<p><iframe class=\"my_chart\" src=\"http://www.mcla.404.ge/_charts/1405799814_ka.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>","ka/youtube","","","1","text","","ka","3","0","","1","0");
INSERT INTO website_menu VALUES("625","1405770935","2","0","Text page","Text page","Text page","<p><iframe class=\"my_chart\" style=\"overflow: hidden;\" src=\"http://www.mcla.404.ge//_charts/1405778423_en.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>","en/text","","","1","text","","en","2","0","","1","0");
INSERT INTO website_menu VALUES("624","1405770935","2","0","ტექსტური გვერდი","ტექსტური გვერდი","ტექსტური გვერდი","<p><iframe class=\"my_chart\" style=\"overflow: hidden;\" src=\"http://www.mcla.404.ge//_charts/1405778423_ka.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\n<p><iframe class=\"my_chart\" src=\"http://www.mcla.404.ge//_charts/1405797350_ka.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\n<p><iframe class=\"my_chart\" src=\"http://www.mcla.404.ge/_charts/1405799814_ka.html\" width=\"100%\" height=\"300\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>","ka/text","","","1","text","","ka","2","0","","1","0");
INSERT INTO website_menu VALUES("634","1405882674","5","2","მორე ტესტი","მორე ტესტი","მორე ტესტი","<p>მორე ტესტი</p>","ka/moretest","","","2","text","","ka","1","0","","1,17","0");
INSERT INTO website_menu VALUES("635","1405882674","5","2","მორე ტესტი","მორე ტესტი","მორე ტესტი","<p>მორე ტესტი</p>","en/moretest","","","2","text","","en","1","0","","1,17","0");
INSERT INTO website_menu VALUES("636","1405882674","5","2","მორე ტესტი","მორე ტესტი","მორე ტესტი","<p>მორე ტესტი</p>","ru/moretest","","","2","text","","ru","1","0","","1,17","0");
INSERT INTO website_menu VALUES("637","1405883809","6","0","სიახლეები","სიახლეები","სიახლეები","<p>სიახლეები</p>","ka/news","","","1","news","","ka","4","0","","1","0");
INSERT INTO website_menu VALUES("638","1405883809","6","0","სიახლეები","სიახლეები","სიახლეები","<p>სიახლეები</p>","en/news","","","1","news","","en","4","0","","1","0");
INSERT INTO website_menu VALUES("639","1405883809","6","0","სიახლეები","სიახლეები","სიახლეები","<p>სიახლეები</p>","ru/news","","","1","news","","ru","4","0","","1","0");
INSERT INTO website_menu VALUES("640","1405888737","7","0","გალერეა","გალერეა","გალერეა","<p>გალერეა</p>","ka/gallery","","","1","gallery","","ka","5","0","","1,17","0");
INSERT INTO website_menu VALUES("641","1405888737","7","0","გალერეა","გალერეა","გალერეა","<p>გალერეა</p>","en/gallery","","","1","gallery","","en","5","0","","1,17","0");
INSERT INTO website_menu VALUES("642","1405888737","7","0","გალერეა","გალერეა","გალერეა","<p>გალერეა</p>","ru/gallery","","","1","gallery","","ru","5","0","","1,17","0");
INSERT INTO website_menu VALUES("643","1405890234","8","0","თანამშრომლები","თანამშრომლები","თანამშრომლები","<p>თანამშრომლები</p>","ka/staff","","","1","catalog","","ka","6","0","","1,17","0");
INSERT INTO website_menu VALUES("644","1405890234","8","0","თანამშრომლები","თანამშრომლები","თანამშრომლები","<p>თანამშრომლები</p>","en/staff","","","1","catalog","","en","6","0","","1,17","0");
INSERT INTO website_menu VALUES("645","1405890234","8","0","თანამშრომლები","თანამშრომლები","თანამშრომლები","<p>თანამშრომლები</p>","ru/staff","","","1","catalog","","ru","6","0","","1,17","0");



DROP TABLE website_news;

CREATE TABLE `website_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `news_category` varchar(255) NOT NULL,
  `langs` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO website_news VALUES("17","1","1405883809","სიახლეები","ru","0");
INSERT INTO website_news VALUES("16","1","1405883809","სიახლეები","en","0");
INSERT INTO website_news VALUES("15","1","1405883809","სიახლეები","ka","0");



DROP TABLE website_news_attachment;

CREATE TABLE `website_news_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `connect_id` int(11) NOT NULL,
  `news_idx` int(11) NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ka',
  `departments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin_permission` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_news_attachment VALUES("17","1","6","1","ru","","");
INSERT INTO website_news_attachment VALUES("16","1","6","1","en","","");
INSERT INTO website_news_attachment VALUES("15","1","6","1","ka","","");



DROP TABLE website_news_items;

CREATE TABLE `website_news_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `news_idx` int(11) NOT NULL,
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `short_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `long_text` text COLLATE utf8_unicode_ci NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `emailed` int(11) NOT NULL,
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_news_items VALUES("37","1","1405800000","1","ნამეტანი ახალი სიახლე","<p>ასკდჯჰასკჯჰდ კჯასჰდჯკასჰდ კჯასჰდ ჯკასჰდ კჯასჰდ ჯასდ კჯასდ კჯასჰ დკჯასდნ ასდკჯ ასკნდ აკსჯ</p>","<p>ჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯს</p>\n<p>&nbsp;</p>\n<p>ჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯს</p>","ka","0","1","0");
INSERT INTO website_news_items VALUES("38","1","1405800000","1","ნამეტანი ახალი სიახლე","<p>ასკდჯჰასკჯჰდ კჯასჰდჯკასჰდ კჯასჰდ ჯკასჰდ კჯასჰდ ჯასდ კჯასდ კჯასჰ დკჯასდნ ასდკჯ ასკნდ აკსჯ</p>","<p>ჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯს</p>\n<p>&nbsp;</p>\n<p>ჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯს</p>","en","0","1","0");
INSERT INTO website_news_items VALUES("39","1","1405800000","1","ნამეტანი ახალი სიახლე","<p>ასკდჯჰასკჯჰდ კჯასჰდჯკასჰდ კჯასჰდ ჯკასჰდ კჯასჰდ ჯასდ კჯასდ კჯასჰ დკჯასდნ ასდკჯ ასკნდ აკსჯ</p>","<p>ჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯს</p>\n<p>&nbsp;</p>\n<p>ჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯსჯაჰდჯ ასკჯდ ჰასკჯჰდ კჯასნდ ასჯდ ნაკსჯ დკჯას ნდნდს ჯაჯკსდნაკჯსნ კჯასნ დკჯს</p>","ru","0","1","0");
INSERT INTO website_news_items VALUES("40","2","1405886400","1","test","<p>test</p>","<p>test test</p>","ka","0","1,17","0");
INSERT INTO website_news_items VALUES("41","2","1405886400","1","test","<p>test</p>","<p>test test</p>","en","0","1,17","0");
INSERT INTO website_news_items VALUES("42","2","1405886400","1","test","<p>test</p>","<p>test test</p>","ru","0","1,17","0");



DROP TABLE website_newsletter;

CREATE TABLE `website_newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `departments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_newsletter VALUES("27","176.73.234.42","1405350770","giorgigvazava87@gmail.com","1","college","1");



DROP TABLE website_poll;

CREATE TABLE `website_poll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `type` enum('a','q') COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=162 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_poll VALUES("161","3","1","1405895527","a","asn 2","ru","","0");
INSERT INTO website_poll VALUES("156","1","0","1405895527","q","test","en","1","0");
INSERT INTO website_poll VALUES("157","2","1","1405895527","a","ans","en","","0");
INSERT INTO website_poll VALUES("158","3","1","1405895527","a","asn 2","en","","0");
INSERT INTO website_poll VALUES("159","1","0","1405895527","q","test","ru","1","0");
INSERT INTO website_poll VALUES("160","2","1","1405895527","a","ans","ru","","0");
INSERT INTO website_poll VALUES("155","3","1","1405895527","a","asn 2","ka","","0");
INSERT INTO website_poll VALUES("154","2","1","1405895527","a","ans","ka","","0");
INSERT INTO website_poll VALUES("153","1","0","1405895527","q","test","ka","1","0");



DROP TABLE website_poll_answers;

CREATE TABLE `website_poll_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `poll_idx` int(11) NOT NULL,
  `answer_idx` int(11) NOT NULL,
  `departments` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE website_slider;

CREATE TABLE `website_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idx` int(11) NOT NULL,
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `text` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `gotourl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url_target` enum('_blank','_self') COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  `langs` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ka',
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_slider VALUES("53","1","სატესტო","ვაი ვაი ვაი","http://www.404.ge","_blank","slide_1405879856.jpg","0","ka","1","0");
INSERT INTO website_slider VALUES("54","1","სატესტო","ვაი ვაი ვაი","http://www.404.ge","_blank","slide_1405879856.jpg","0","en","1","0");
INSERT INTO website_slider VALUES("55","1","სატესტო","ვაი ვაი ვაი","http://www.404.ge","_blank","slide_1405879856.jpg","0","ru","1","0");



DROP TABLE website_social;

CREATE TABLE `website_social` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `var` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_social VALUES("1","facebook","http://facebook.com");
INSERT INTO website_social VALUES("2","youtube","http:/youtube.com");
INSERT INTO website_social VALUES("3","twitter","http://twitter.ge");



DROP TABLE website_youtube;

CREATE TABLE `website_youtube` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `channel_username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `channel_link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'API key',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `app_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'google account',
  `access_admins` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_youtube VALUES("2","გიოს არხი","","https://www.youtube.com/user/mavne1987able","AIzaSyBeBBJMNxF2zz2b6X17XvZGNcniOEBTTLQ","giorgigvazava87@gmail.com","kujxcktdhnozmnma","1","0");
INSERT INTO website_youtube VALUES("3","საქართველოს ბიზნესისა და მართვის აკადემია","akademqalaqi","https://www.youtube.com/channel/UCEqhqdkKtA0U7Qym5tuvr1Q","AIzaSyDFKVy4MPuT6LAM6DImBB9YR_MWG42T5fQ","akademqalaqi@gmail.com","education201","1","0");



DROP TABLE website_youtube_videos;

CREATE TABLE `website_youtube_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `croned_time` int(11) NOT NULL,
  `channel_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `video_file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `private` int(11) NOT NULL,
  `video_link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `departments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `upload_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `upload_error` text COLLATE utf8_unicode_ci NOT NULL,
  `admin_permission` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO website_youtube_videos VALUES("34","1403548413","2","ტესტ","<p>ტესტ</p>","Entertainment","ცხოველები, ველური ბუნება","1403542382.mp4","0","OtBu8rBEpyI","college","uploaded","","","0");
INSERT INTO website_youtube_videos VALUES("40","1403640013","2","ტესტ 2","<p>ტესტ 2</p>","Travel","სესხი, თიბისი","1403639755.mp4","0","79ddMFTjiNo","college","uploaded","","","0");
INSERT INTO website_youtube_videos VALUES("41","1403707646","3","სატესტო","<p>სატესტო</p>","Education","განათლება, სწავლა","1403707597.mp4","0","vOeR0y6HwsA","college","uploaded","","","0");
INSERT INTO website_youtube_videos VALUES("42","1403991903","3","testii","<p>testii</p>","Education","აბორიგენები, ინდიელები","","0","TABzq99klyU","college","uploaded","","","0");



